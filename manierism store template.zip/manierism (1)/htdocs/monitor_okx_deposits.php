<?php
// monitor_okx_deposits.php - Cron script (run every 1-5 min) to poll OKX deposits and match pendings
// Setup: Add to crontab: */5 * * * * php /path/to/monitor_okx_deposits.php

require_once 'okx_auth.php'; // Separate file for OKX auth functions (see below)

$pending_file = __DIR__ . '/pending_payments.json';
$wallets_dir = __DIR__ . '/wallets';

$pendings = file_exists($pending_file) ? json_decode(file_get_contents($pending_file), true) : [];
if (empty($pendings)) exit('No pendings');

// Poll OKX for recent deposits (last 10 min)
$since = time() - 600; // 10 min ago
$deposits = fetchOkxDeposits('USDT', $since); // Implement based on ccy

foreach ($deposits as $dep) {
    $dep_time = intval($dep['ts'] ?? 0) / 1000;
    $dep_amt_usd = floatval($dep['amt'] ?? 0); // Assume amt is in USD equiv or convert

    foreach ($pendings as $key => $pending) {
        if ($pending['status'] !== 'pending') continue;

        $time_diff = abs($dep_time - ($pending['timestamp'] / 1000));
        $amt_diff = abs($dep_amt_usd - $pending['amount_usd']);
        $tol_time = 300; // 5 min
        $tol_amt = 0.01; // 1 cent

        if ($time_diff <= $tol_time && $amt_diff <= $tol_amt && $pending['ccy'] === 'USDT') {
            // Match! Credit balance
            creditBalance($pending['wallet_id'], $pending['action'], $pending['amount_usd']);

            // Update pending
            $pendings[$key]['status'] = 'confirmed';
            $pendings[$key]['dep_id'] = $dep['depId'] ?? '';
            $pendings[$key]['tx_id'] = $dep['txId'] ?? '';
            $pendings[$key]['confirmed_at'] = time();

            echo "Matched payment for {$pending['wallet_id']}: {$pending['action']} for \${$pending['amount_usd']}\n";
        }
    }
}

// Save updated pendings
file_put_contents($pending_file, json_encode($pendings, JSON_PRETTY_PRINT), LOCK_EX);

// Helper: Credit balance based on action
function creditBalance($wallet_id, $action, $amount_usd) {
    global $wallets_dir;
    $wallet_file = $wallets_dir . '/' . md5($wallet_id) . '.json';
    if (!file_exists($wallet_file)) return false;

    $balances = json_decode(file_get_contents($wallet_file), true) ?: [];
    $watts_reward = floor($amount_usd / 0.50) * 17;

    switch ($action) {
        case 'buy150':
            $balances['real_kwh'] = ($balances['real_kwh'] ?? 0) + 150;
            break;
        case 'sell7':
            if (($balances['real_kwh'] ?? 0) >= 7) {
                $balances['real_kwh'] -= 7;
                $balances['usd_value'] = ($balances['usd_value'] ?? 0) + 0.80;
                $balances['watts_dollar'] = ($balances['watts_dollar'] ?? 0) + 0.35;
                $balances['profit_usd'] = ($balances['profit_usd'] ?? 0) + 0.20; // Admin fee as profit
            }
            break;
        case 'list':
            // For listing, assume kWh locked in escrow (from original)
            // ... (integrate with listing.php logic)
            break;
        case 'usd_swap':
            $balances['profit_usd'] = ($balances['profit_usd'] ?? 0) + 0.01; // Fee
            break;
    }

    if ($watts_reward > 0) {
        $balances['watts_dollar'] = ($balances['watts_dollar'] ?? 0) + $watts_reward;
    }

    file_put_contents($wallet_file, json_encode($balances, JSON_PRETTY_PRINT), LOCK_EX);
    return true;
}

// Fetch recent deposits from OKX
function fetchOkxDeposits($ccy, $since) {
    $path = '/api/v5/asset/deposit-history?ccy=' . $ccy . '&state=2&limit=10'; // Confirmed deposits
    $res = okxRequest('GET', $path);
    if ($res['code'] === '0') {
        return array_filter($res['data'], fn($d) => intval($d['ts']) / 1000 >= $since);
    }
    return [];
}
?>