<?php
// sell_kwh_7.php — Deduct 7 kWh, credit $0.80 USD and 0.35 Watts Dollar, then output receipt
declare(strict_types=1);

header('Content-Type: application/json');

$file     = __DIR__ . '/balances.json';
$log_file = __DIR__ . '/trades_log.json';

$SELL_AMOUNT_KWH = 7.0;
$USD_CREDIT      = 0.80;
$WATTS_CREDIT    = 0.35;

// --- 1. Load balances with exclusive lock ---
$fp = fopen($file, 'c+');
if (!$fp || !flock($fp, LOCK_EX)) {
    http_response_code(500);
    exit(json_encode(["status"=>"error","message"=>"Balance file error/lock failed"]));
}

$balances = json_decode(stream_get_contents($fp), true) ?? [];
if (!is_array($balances)) $balances = [];

$remaining = $balances['real_kwh'] ?? 0;
if ($remaining < $SELL_AMOUNT_KWH) {
    flock($fp, LOCK_UN); fclose($fp);
    http_response_code(409);
    exit(json_encode(["status"=>"error","message"=>"Insufficient balance to sell {$SELL_AMOUNT_KWH} kWh"]));
}

// --- 2. Deduct and credit ---
$balances['real_kwh']    = ($balances['real_kwh'] ?? 0) - $SELL_AMOUNT_KWH;
$balances['usd_value']   = ($balances['usd_value'] ?? 0) + $USD_CREDIT;
$balances['watts_dollar']= ($balances['watts_dollar'] ?? 0) + $WATTS_CREDIT;
$balances['last_updated']= gmdate("c");

// Write back balances
ftruncate($fp, 0); rewind($fp);
fwrite($fp, json_encode($balances, JSON_PRETTY_PRINT));
fflush($fp); flock($fp, LOCK_UN); fclose($fp);

// --- 3. Build receipt ---
$receiptId = bin2hex(random_bytes(8));
$receipt = [
    "wallet_id"   => $balances['wallet_id'] ?? "william",
    "rig_id"      => $balances['rig_id'] ?? "william",
    "node_id"     => uniqid("sell-", true),
    "resource"    => "sell_kwh",
    "amount_kwh"  => $SELL_AMOUNT_KWH,
    "usd_credit"  => $USD_CREDIT,
    "watts_credit"=> $WATTS_CREDIT,
    "timestamp"   => microtime(true),
    "last_updated"=> gmdate("c"),
    "receipt_meta"=> [
        "receipt_id" => $receiptId,
        "issued_at"  => gmdate("c"),
        "source"     => "Sell Kilowatts"
    ]
];

// --- 4. Log trade ---
$log_entry = [
    'timestamp'    => date('Y-m-d H:i:s'),
    'wallet_id'    => $balances['wallet_id'] ?? 'trust',
    'action'       => 'sell_kwh',
    'amount_kwh'   => $SELL_AMOUNT_KWH,
    'usd_credit'   => $USD_CREDIT,
    'watts_credit' => $WATTS_CREDIT,
    'ip'           => $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN'
];
$fpLog = fopen($log_file, 'c+');
if ($fpLog && flock($fpLog, LOCK_EX)) {
    $data = stream_get_contents($fpLog, -1, 0);
    $current_log = !empty($data) ? json_decode($data, true) : [];
    if (!is_array($current_log)) $current_log = [];
    $current_log[] = $log_entry;
    ftruncate($fpLog, 0); rewind($fpLog);
    fwrite($fpLog, json_encode($current_log, JSON_PRETTY_PRINT));
    flock($fpLog, LOCK_UN);
    fclose($fpLog);
}

// --- 5. Force download of receipt ---
header('Content-Disposition: attachment; filename="sell_kwh_7_' . $receiptId . '.json"');
echo json_encode($receipt, JSON_PRETTY_PRINT);
exit;
?>
