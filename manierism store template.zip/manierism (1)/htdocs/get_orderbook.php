<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=UTF-8');

$orders_file = __DIR__ . '/orders.json';

$bids = [];
$asks = [];

// Load real orders from storage
if (file_exists($orders_file)) {
    $raw = file_get_contents($orders_file);
    $orders = json_decode($raw, true);

    if (is_array($orders)) {
        foreach ($orders as $o) {
            if (!isset($o['type']) || !isset($o['watts_dollar'])) continue;

            $price  = floatval($o['watts_dollar']);
            $amount = floatval($o['usd_amount'] ?? 0);
            $ts     = $o['created_at'] ?? time();

            if (strtoupper($o['type']) === "BUY") {
                $bids[] = [
                    "price" => $price,
                    "amount" => $amount,
                    "created" => $ts
                ];
            }
            elseif (strtoupper($o['type']) === "SELL") {
                $asks[] = [
                    "price" => $price,
                    "amount" => $amount,
                    "created" => $ts
                ];
            }
        }
    }
}

// Sort for correct market orderbook display
usort($bids, fn($a, $b) => $b['price'] <=> $a['price']);  // Higher first
usort($asks, fn($a, $b) => $a['price'] <=> $b['price']);  // Lower first

// Spread calculation
$spread = "N/A";
if (!empty($bids) && !empty($asks)) {
    $spread = round(($asks[0]['price'] - $bids[0]['price']), 6);
}

// Output final structure
echo json_encode([
    "status" => "ok",
    "orderbook" => [
        "bids" => $bids,
        "asks" => $asks,
        "spread" => $spread
    ],
    "timestamp" => gmdate('c')
], JSON_PRETTY_PRINT);
?>