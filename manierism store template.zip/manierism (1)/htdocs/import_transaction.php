<?php
// import_transaction.php — process uploaded transaction JSON and update wallet balances
declare(strict_types=1);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// --- Configuration ---
$LEDGER_FILE = __DIR__ . '/transaction_ledger.json';
$WALLET_DIR  = __DIR__ . '/wallets/';

// --- Helper for errors ---
function sendError(string $message, int $status_code = 400): void {
    http_response_code($status_code);
    echo json_encode(["status" => "error", "message" => $message]);
    exit();
}

// --- Load ledger of processed node IDs ---
$ledger = file_exists($LEDGER_FILE) ? json_decode(file_get_contents($LEDGER_FILE), true) : [];
if (!is_array($ledger)) $ledger = [];

// --- Read uploaded JSON (assumes raw POST body contains JSON) ---
$uploaded_json_content = file_get_contents('php://input');
if ($uploaded_json_content === false || $uploaded_json_content === '') {
    sendError("No transaction data received", 400);
}

$transaction_data = json_decode($uploaded_json_content, true);
if (json_last_error() !== JSON_ERROR_NONE || !is_array($transaction_data)) {
    sendError("Invalid JSON in transaction file", 400);
}

// --- Validate required fields ---
if (!isset($transaction_data['node_id'], $transaction_data['wallet_id'], $transaction_data['resource'], $transaction_data['amount'])) {
    sendError("Invalid transaction file structure. Required fields missing.", 400);
}

$node_id   = (string)$transaction_data['node_id'];
$wallet_id = preg_replace('/[^a-zA-Z0-9_\-]/', '', (string)$transaction_data['wallet_id']); // sanitize filename
$amount    = (float)$transaction_data['amount'];
$resource  = (string)$transaction_data['resource'];

// --- Check "once per file" rule ---
if (in_array($node_id, $ledger, true)) {
    sendError("Transaction node_id '{$node_id}' already processed.", 400);
}

// --- Load or initialize wallet file ---
$wallet_path = $WALLET_DIR . "{$wallet_id}.json";
$wallet = file_exists($wallet_path) ? json_decode(file_get_contents($wallet_path), true) : null;
if (!is_array($wallet)) {
    $wallet = ['wallet_id' => $wallet_id, 'real_kwh_balance' => 0];
}

// --- Process transaction ---
if ($resource === 'real_kwh') {
    $wallet['real_kwh_balance'] = (float)($wallet['real_kwh_balance'] ?? 0) + $amount;

    // Update ledger and wallet with file locks
    $fpLedger = fopen($LEDGER_FILE, 'c+');
    if ($fpLedger && flock($fpLedger, LOCK_EX)) {
        $ledger[] = $node_id;
        ftruncate($fpLedger, 0);
        rewind($fpLedger);
        fwrite($fpLedger, json_encode($ledger, JSON_PRETTY_PRINT));
        flock($fpLedger, LOCK_UN);
        fclose($fpLedger);
    } else {
        sendError("Failed to lock ledger file for writing", 500);
    }

    $fpWallet = fopen($wallet_path, 'c+');
    if ($fpWallet && flock($fpWallet, LOCK_EX)) {
        ftruncate($fpWallet, 0);
        rewind($fpWallet);
        fwrite($fpWallet, json_encode($wallet, JSON_PRETTY_PRINT));
        flock($fpWallet, LOCK_UN);
        fclose($fpWallet);
    } else {
        sendError("Failed to lock wallet file for writing", 500);
    }

    echo json_encode([
        "status"      => "success",
        "message"     => "Successfully imported {$amount} real_kwh for wallet '{$wallet_id}'.",
        "new_balance" => $wallet['real_kwh_balance']
    ]);
} else {
    echo json_encode([
        "status"  => "warning",
        "message" => "Resource '{$resource}' is not configured for automatic balance import."
    ]);
}

exit();
