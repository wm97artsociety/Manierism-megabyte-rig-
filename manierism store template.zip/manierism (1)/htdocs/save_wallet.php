<?php
// save_wallet.php — MULTI-WALLET + ORDERBOOK COMPATIBLE
declare(strict_types=1);
require __DIR__ . '/db.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Content-Type: application/json; charset=UTF-8');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);

if (!is_array($data)) {
    http_response_code(400);
    echo json_encode(["status"=>"error","message"=>"Invalid JSON body"]);
    exit;
}

// ✅ EXACT SAME DEFAULTS as wallet_balances.php
$defaults = [
    "capsule_mb"    => 0.0,
    "cache_mb"      => 0.0,
    "real_kwh"      => 50.0,
    "bandwidth"     => 0.0,
    "torrent_mb"    => 0.0,
    "watts_dollar"  => 7.50,
    "usd_value"     => 0.0,
    "account_usd"   => 0.0,
    "profit_usd"    => 0.0,
    "liquidity_usd" => 0.0,
    "last_updated"  => gmdate("c")
];

// ✅ MERGE + FLOAT CONVERSION
$merged = array_merge($defaults, array_intersect_key($data, $defaults));
foreach ($merged as $k => $v) { 
    $merged[$k] = is_numeric($v) ? (float)$v : 0.0; 
}

// ✅ GET WALLET ID (from POST or fallback)
$wallet_id = $data['wallet_id'] ?? $_GET['wallet_id'] ?? 'trust';

try {
    if (!isset($pdo)) {
        throw new Exception("Database unavailable");
    }
    
    // ✅ MULTI-WALLET: DYNAMIC wallet_id
    $stmt = $pdo->prepare("
        INSERT INTO balances 
        (wallet_id, capsule_mb, cache_mb, real_kwh, bandwidth, torrent_mb, 
         watts_dollar, usd_value, account_usd, profit_usd, liquidity_usd, last_updated)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ON DUPLICATE KEY UPDATE
            capsule_mb=VALUES(capsule_mb),
            cache_mb=VALUES(cache_mb),
            real_kwh=VALUES(real_kwh),
            bandwidth=VALUES(bandwidth),
            torrent_mb=VALUES(torrent_mb),
            watts_dollar=VALUES(watts_dollar),
            usd_value=VALUES(usd_value),
            account_usd=VALUES(account_usd),
            profit_usd=VALUES(profit_usd),
            liquidity_usd=VALUES(liquidity_usd),
            last_updated=NOW()
    ");
    
    // ✅ 11 VALUES: wallet_id + 10 balances
    $stmt->execute([
        $wallet_id,                           // ✅ DYNAMIC WALLET ID
        $merged['capsule_mb'],
        $merged['cache_mb'], 
        $merged['real_kwh'],
        $merged['bandwidth'],
        $merged['torrent_mb'],
        $merged['watts_dollar'],
        $merged['usd_value'],
        $merged['account_usd'],
        $merged['profit_usd'],
        $merged['liquidity_usd']
    ]);

    // ✅ ALSO SAVE TO JSON (BACKUP + HTML COMPAT)
    $json_file = __DIR__ . '/wallets/' . md5($wallet_id) . '.json';
    if (!is_dir(__DIR__ . '/wallets')) {
        mkdir(__DIR__ . '/wallets', 0755, true);
    }
    $merged['wallet_id'] = $wallet_id;
    $merged['last_updated'] = gmdate("c");
    file_put_contents($json_file, json_encode($merged, JSON_PRETTY_PRINT));

    echo json_encode([
        "status" => "ok", 
        "wallet_id" => $wallet_id,
        "balances" => $merged,
        "saved" => true,
        "method" => "MySQL + JSON"
    ], JSON_PRETTY_PRINT);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        "status" => "error", 
        "message" => "Save failed: " . $e->getMessage()
    ], JSON_PRETTY_PRINT);
    exit;
}
?>