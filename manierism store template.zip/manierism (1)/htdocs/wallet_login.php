<?php
// wallet_login.php — grant one-time welcome gift per IP
declare(strict_types=1);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$balances_file = __DIR__ . '/balances.json';
$log_file      = __DIR__ . '/wallet_log.json';
$gift_file     = __DIR__ . '/gift_log.json';

// Default welcome gift values
$welcomeGift = [
    "capsule_mb"   => 10.00,
    "cache_mb"     => 25.00,
    "real_kwh"     => 10.00,
    "bandwidth"    => 10.00,
    "torrent_mb"   => 50.00,
    "watts_dollar" => 17.50,
    "usd_value"    => 0.00,
    "profit_usd"   => 0.00,
    "liquidity_usd"=> 100000.00
];

// --- Helper for errors ---
function sendError(string $message, int $status_code = 400): void {
    http_response_code($status_code);
    echo json_encode(["status" => "error", "message" => $message]);
    exit();
}

// --- Read JSON body ---
$raw = file_get_contents("php://input");
$data = json_decode($raw, true);

if (!$data || empty($data['wallet_id'])) {
    sendError("Missing wallet_id or invalid JSON", 400);
}

// --- Determine client IP ---
$clientIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

// --- Load gift log ---
$giftLog = file_exists($gift_file) ? json_decode(file_get_contents($gift_file), true) : [];
if (!is_array($giftLog)) $giftLog = [];

// --- Check if IP already received gift ---
if (!isset($giftLog[$clientIp])) {
    // First time this IP connects → grant welcome gift
    $balances = $welcomeGift;
    $giftLog[$clientIp] = [
        "wallet_id" => $data['wallet_id'],
        "timestamp" => date('Y-m-d H:i:s')
    ];
    file_put_contents($gift_file, json_encode($giftLog, JSON_PRETTY_PRINT));
} else {
    // Already received → load existing balances
    $balances = file_exists($balances_file)
        ? json_decode(file_get_contents($balances_file), true)
        : $welcomeGift;
}

// --- Save balances ---
file_put_contents($balances_file, json_encode($balances, JSON_PRETTY_PRINT));

// --- Log wallet login ---
$log_entry = [
    "timestamp" => date('Y-m-d H:i:s'),
    "wallet_id" => $data['wallet_id'],
    "ip"        => $clientIp,
    "balances"  => $balances
];
$current_log = file_exists($log_file) ? json_decode(file_get_contents($log_file), true) : [];
if (!is_array($current_log)) $current_log = [];
$current_log[] = $log_entry;
file_put_contents($log_file, json_encode($current_log, JSON_PRETTY_PRINT));

// --- Respond ---
echo json_encode([
    "status"   => "ok",
    "message"  => isset($giftLog[$clientIp]) ? "Welcome gift applied once per IP." : "Wallet login successful.",
    "wallet"   => $data['wallet_id'],
    "ip"       => $clientIp,
    "balances" => $balances
]);
exit;
