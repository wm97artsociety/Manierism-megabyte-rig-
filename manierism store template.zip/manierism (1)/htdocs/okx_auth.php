<?php
// okx_auth.php - OKX API Auth Helper
function okxRequest($method, $path, $body = '') {
    $config = [
        'apiKey' => 'YOUR_OKX_API_KEY',
        'secret' => 'YOUR_OKX_SECRET',
        'passphrase' => 'YOUR_PASSPHRASE',
        'baseUrl' => 'https://www.okx.com'
    ];

    $timestamp = gmdate('c', time());
    $signStr = $timestamp . strtoupper($method) . $path . $body;
    $signature = base64_encode(hash_hmac('sha256', $signStr, $config['secret'], true));

    $headers = [
        'OK-ACCESS-KEY: ' . $config['apiKey'],
        'OK-ACCESS-SIGN: ' . $signature,
        'OK-ACCESS-TIMESTAMP: ' . $timestamp,
        'OK-ACCESS-PASSPHRASE: ' . $config['passphrase'],
        'Content-Type: application/json'
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $config['baseUrl'] . $path);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    if ($method !== 'GET') curl_setopt($ch, CURLOPT_POSTFIELDS, $body);

    $response = curl_exec($ch);
    curl_close($ch);
    return json_decode($response, true);
}
?>