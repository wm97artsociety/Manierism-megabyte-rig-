<?php

// ----------------------------------------------------------------------
// 1. Database Connection Configuration
// ----------------------------------------------------------------------
define('DB_HOST', '');
define('DB_USER', '');
define('DB_PASS', '');
define('DB_NAME', '');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ----------------------------------------------------------------------
// 2. Process Form Submission (Only runs if the form was posted)
// ----------------------------------------------------------------------

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Safely retrieve form data. Use a default empty string if a field is missing.
    $name         = trim($_POST['name'] ?? '');
    $description  = trim($_POST['description'] ?? '');
    $keywords     = trim($_POST['keywords'] ?? '');
    $maticPrice   = trim($_POST['maticPrice'] ?? '');
    $imageUrl     = trim($_POST['imageUrl'] ?? '');
    $sellerWallet = trim($_POST['sellerWallet'] ?? '');

    // Convert price to a float for safe SQL insertion
    $maticPrice = (float)$maticPrice;

    // Basic Validation: Ensure required fields are not empty
    if (empty($name) || empty($maticPrice) || empty($sellerWallet)) {
        echo "<p style='color:red;'>Error: Name, Price, and Wallet Address are required fields.</p>";
    } else {

        // ------------------------------------------------------------------
        // 3. Prepare SQL Statement for Secure Insertion (Using Prepared Statements)
        // ------------------------------------------------------------------
        $sql = "INSERT INTO products (name, description, keywords, maticPrice, imageUrl, sellerWallet) 
                VALUES (?, ?, ?, ?, ?, ?)";
        
        // Prepare the statement
        $stmt = $conn->prepare($sql);

        if ($stmt === false) {
            die("SQL Preparation Error: " . $conn->error);
        }

        /*
         * Bind parameters:
         * 's' - string
         * 'd' - double/decimal (for maticPrice)
         * We use 's' for most values, and 'd' for the maticPrice.
         */
        $stmt->bind_param("sssds", $name, $description, $keywords, $maticPrice, $imageUrl, $sellerWallet);

        // 4. Execute the statement
        if ($stmt->execute()) {
            echo "<h2>Success!</h2><p>New product created successfully with ID: " . $stmt->insert_id . "</p>";
        } else {
            echo "<p style='color:red;'>Error inserting record: " . $stmt->error . "</p>";
        }

        // Close the statement
        $stmt->close();
    }
}

// Close the main connection
$conn->close();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add New Product</title>
</head>
<body>
    <h1>Add a New Product to the Database</h1>
    <form method="POST" action="add_product.php">
        
        <label for="name">Name (Required):</label><br>
        <input type="text" id="name" name="name" required><br><br>

        <label for="maticPrice">Price (MATIC - Required):</label><br>
        <input type="number" step="0.01" id="maticPrice" name="maticPrice" required><br><br>

        <label for="sellerWallet">Seller Wallet (Required):</label><br>
        <input type="text" id="sellerWallet" name="sellerWallet" required><br><br>
        
        <label for="description">Description:</label><br>
        <textarea id="description" name="description"></textarea><br><br>

        <label for="keywords">Keywords (comma-separated):</label><br>
        <input type="text" id="keywords" name="keywords"><br><br>

        <label for="imageUrl">Image URL:</label><br>
        <input type="text" id="imageUrl" name="imageUrl" placeholder="https://yourdomain.com/images/product.jpg"><br><br>

        <input type="submit" value="Submit Product">
    </form>
</body>
</html>