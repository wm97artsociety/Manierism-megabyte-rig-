<?php
header('Content-Type: application/json');

// --- Database connection ---
$servername = "sql300.infinityfree.com";
$username   = "if0_40369406";
$password   = "Manierism1997$";
$dbname     = "if0_40369406_manierism";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    echo json_encode(["error" => "DB connection failed: " . $conn->connect_error]);
    exit;
}

// --- Get POST data ---
$name        = $_POST['name'] ?? '';
$description = $_POST['description'] ?? '';
$keywords    = $_POST['keywords'] ?? '';
$maticPrice  = $_POST['maticPrice'] ?? 0;
$imageUrl    = $_POST['imageUrl'] ?? '';
$sellerWallet= $_POST['sellerWallet'] ?? '';

if (!$name || !$description || !$maticPrice) {
    echo json_encode(["error" => "Missing required fields"]);
    exit;
}

// --- Insert product ---
$stmt = $conn->prepare("INSERT INTO products (name, description, keywords, maticPrice, imageUrl, sellerWallet) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssiss", $name, $description, $keywords, $maticPrice, $imageUrl, $sellerWallet);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "id" => $stmt->insert_id]);
} else {
    echo json_encode(["error" => $stmt->error]);
}

$stmt->close();
$conn->close();
?>
