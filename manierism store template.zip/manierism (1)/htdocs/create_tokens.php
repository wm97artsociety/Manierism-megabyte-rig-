<?php
// PHP Script to handle the creation of a token (simulated debit) and update the balance log.

header("Access-Control-Allow-Origin: *");
header('Content-Type: application/json');

// --- Configuration ---
$log_file = 'wallet_balances_log.json';
$costUsd = 0.50; // Cost is now set to $0.50 USD
$walletId = 'trust'; // Fixed ID for consistency

// --- File Locking Utility ---
// Attempts a non-blocking lock to prevent file corruption during read/write
$fp = fopen($log_file, 'c+');
if (!$fp) {
    echo json_encode(['status' => 'error', 'message' => "Could not open log file for locking."]);
    exit();
}

// Acquire an exclusive lock (non-blocking)
if (!flock($fp, LOCK_EX | LOCK_NB)) {
    fclose($fp);
    echo json_encode(['status' => 'error', 'message' => "Another transaction is in progress. Try again."]);
    exit();
}

// --- 1. Load the Balance ---
$current_log = [];
$log_content = stream_get_contents($fp, -1, 0); // Read the whole file from the start
$decoded_log = [];

if ($log_content) {
    $decoded_log = json_decode($log_content, true);
    if (json_last_error() === JSON_ERROR_NONE && is_array($decoded_log) && !empty($decoded_log)) {
        // Get the LAST (most recent) entry, which acts as the current balance
        $last_balance = end($decoded_log);
        if (is_array($last_balance)) {
            $current_log = $last_balance;
        }
    }
}

// Default initial state if no log or corrupted log is found
if (empty($current_log) || !isset($current_log['watts_dollar'])) {
    $current_log = [
        'capsule_mb' => 0, 'cache_mb' => 0, 'real_kwh' => 0, 
        'bandwidth' => 0, 'torrent_mb' => 0, 'watts_dollar' => 150.00, // Starting default Watts Dollar
        'usd_value' => 100.00, // Starting default USD value
        'profit_usd' => 0.00,
        'timestamp' => time()
    ];
}

// --- 2. Perform Transaction and Check Funds ---
$initialUsd = (float)($current_log['usd_value'] ?? 0);
$initialWatts = (float)($current_log['watts_dollar'] ?? 0);

if ($initialUsd < $costUsd) {
    flock($fp, LOCK_UN); // Release lock
    fclose($fp);
    http_response_code(402); // Payment Required
    echo json_encode(['status' => 'error', 'message' => "Insufficient USD balance to create token (Need: $$costUsd). Current: $$initialUsd"]);
    exit();
}

// Calculate new balances: Debit USD, Watts Dollar remains the same (as USD is the cost)
$newUsd = $initialUsd - $costUsd;

// --- 3. Prepare New Log Entry ---
$new_entry = $current_log; // Start with the old entry
$new_entry['usd_value'] = $newUsd;
$new_entry['timestamp'] = time();
$new_entry['action'] = "token_creation_debit_usd";

// --- 4. Append and Save Log ---
if (!is_array($decoded_log)) {
    $decoded_log = [];
}
$decoded_log[] = $new_entry;

$json_output = json_encode($decoded_log, JSON_PRETTY_PRINT);

// Rewind and truncate the file before writing new content
ftruncate($fp, 0);
rewind($fp);
fwrite($fp, $json_output);

// Release lock and close file
flock($fp, LOCK_UN);
fclose($fp);

// --- 5. Return Success Response ---
echo json_encode([
    'status' => 'success', 
    'message' => "Token created successfully. Debited $$costUsd from USD value.",
    'new_balance' => $new_entry
]);
?>