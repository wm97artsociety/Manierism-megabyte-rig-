<?php
// wallet_balances.php - Safely retrieves account balances and logs the access.
declare(strict_types=1);

header('Content-Type: application/json');

$file = __DIR__ . '/balances.json';
$log_file = __DIR__ . '/trades_log.json';

// Define the default balances structure
$default = [
    "capsule_mb"   => 100.0,
    "cache_mb"     => 70.0,
    "real_kwh"     => 50.0,
    "bandwidth"    => 200.0,
    "torrent_mb"   => 30.0,
    "watts_dollar" => 7.5,
    "usd_value"    => 0.0,
    "profit_usd"   => 0.0,
    "kilowatt_liquidy_usd"=> 100000.0
];

$balances = $default;

// --- 1. Load balances with a shared lock (LOCK_SH) for safe reading ---
if (!file_exists($file)) {
    file_put_contents($file, json_encode($default, JSON_PRETTY_PRINT));
}

$fpBalances = fopen($file, 'r');
if ($fpBalances) {
    if (flock($fpBalances, LOCK_SH)) {
        $data = fread($fpBalances, filesize($file));
        flock($fpBalances, LOCK_UN);
        $tempBalances = json_decode($data, true);
        if (is_array($tempBalances)) {
            $balances = $tempBalances;
        }
    }
    fclose($fpBalances);
}

// === HANDLE DONATION ACTION (NEW) ===
$action = $_GET['action'] ?? '';
if ($action === 'donation_50') {
    $fp = fopen($file, 'c+');
    if ($fp && flock($fp, LOCK_EX)) {
        $data = stream_get_contents($fp);
        $current = json_decode($data, true) ?: $default;
        $current['watts_dollar'] += 1700.00;
        $current['profit_usd']   += 50.00;
        ftruncate($fp, 0);
        rewind($fp);
        fwrite($fp, json_encode($current, JSON_PRETTY_PRINT));
        flock($fp, LOCK_UN);
        fclose($fp);

        $log_entry = [
            'timestamp' => date('Y-m-d H:i:s'),
            'action'    => 'donation_50',
            'watts_credited' => 1700,
            'profit_added' => 50.00
        ];
        $log_fp = fopen($log_file, 'c+');
        if ($log_fp && flock($log_fp, LOCK_EX)) {
            $log_data = stream_get_contents($log_fp);
            $log = json_decode($log_data, true) ?: [];
            $log[] = $log_entry;
            ftruncate($log_fp, 0);
            rewind($log_fp);
            fwrite($log_fp, json_encode($log, JSON_PRETTY_PRINT));
            flock($log_fp, LOCK_UN);
            fclose($log_fp);
        }

        echo json_encode(['status' => 'ok', 'credited' => 1700]);
        exit;
    }
}

// --- 2. Append to trades_log.json with an exclusive lock ---
$log_entry = [
    'timestamp' => date('Y-m-d H:i:s'),
    'wallet_id' => 'trust',
    'action'    => 'balances_read'
];
$current_log = [];

$fpLog = fopen($log_file, 'c+');
if ($fpLog) {
    if (flock($fpLog, LOCK_EX)) {
        $data = stream_get_contents($fpLog, -1, 0);
        if (!empty($data)) {
            $tempLog = json_decode($data, true);
            if (is_array($tempLog)) {
                $current_log = $tempLog;
            }
        }
        $current_log[] = $log_entry;
        ftruncate($fpLog, 0);
        rewind($fpLog);
        fwrite($fpLog, json_encode($current_log, JSON_PRETTY_PRINT));
        flock($fpLog, LOCK_UN);
    }
    fclose($fpLog);
}

// --- 3. Respond ---
echo json_encode([
    "status"   => "ok",
    "balances" => $balances
]);
?>