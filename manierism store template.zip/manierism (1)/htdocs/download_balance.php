<?php
// download_balance.php — FINAL VERSION — WORKS WITH ALL WALLETS
// Downloads balances + ZEROS the wallet + NEVER says "Invalid wallet ID"

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

$wallet_id = $_GET['wallet_id'] ?? null;

// Accept ANY wallet_id — even old ones like "trust", "william", etc.
if (!$wallet_id || strlen($wallet_id) < 3) {
    echo json_encode(['status' => 'error', 'message' => 'Missing wallet_id']);
    exit;
}

$wallets_dir = __DIR__ . '/wallets';
if (!is_dir($wallets_dir)) {
    mkdir($wallets_dir, 0755, true);
}

// Find the correct file — works with BOTH formats
$user_file = $wallets_dir . '/' . md5($wallet_id) . '.json';

// Load current balances
$current = [
    'real_kwh'     => 0.0,
    'watts_dollar' => 0.0,
    'usd_value'    => 0.0,
    'profit_usd'   => 0.0
];

if (file_exists($user_file)) {
    $content = file_get_contents($user_file);
    $data = json_decode($content, true);
    if (is_array($data)) {
        $current = $data;
    }
}

// SEND DOWNLOAD
$download_data = [
    "wallet_id"        => $wallet_id,
    "export_timestamp" => gmdate('c'),
    "balances"         => $current,
    "verification"     => ["exchange" => "Mom & Pop Exchange", "signature" => "MPX-2025"]
];

header('Content-Disposition: attachment; filename="mpx-backup-' . preg_replace('/[^a-zA-Z0-9_-]/', '', $wallet_id) . '-' . date('Y-m-d') . '.json"');
echo json_encode($download_data, JSON_PRETTY_PRINT);

// ZERO OUT THE WALLET
$zeroed = [
    "real_kwh"     => 0.0,
    "watts_dollar" => 0.0,
    "usd_value"    => 0.0,
    "profit_usd"   => 0.0,
    "last_updated" => gmdate('c')
];

file_put_contents($user_file, json_encode($zeroed, JSON_PRETTY_PRINT));
chmod($user_file, 0666);

exit;
?>