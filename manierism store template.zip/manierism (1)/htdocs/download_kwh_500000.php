<?php
// claim_binary_capsule.php - Handles the big form submission

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.html');
    exit;
}

$name = htmlspecialchars($_POST['customer_name'] ?? 'Anonymous');
$email = filter_var($_POST['customer_email'], FILTER_VALIDATE_EMAIL) ? $_POST['customer_email'] : 'hidden@grid.earth';
$plan = htmlspecialchars($_POST['kilowatt_plan'] ?? 'Amplify the infinite');
$thanks = htmlspecialchars($_POST['thank_you_note'] ?? 'Thank you, William);

$node_id = 'binary-mega-' . bin2hex(random_bytes(6));

$data = [
    "claimer_name" => $name,
    "claimer_email" => $email,
    "wallet_id" => "trust_grid_earth",
    "node_id" => $node_id,
    "resource" => "symbolic_mega_kilowatts",
    "amount_kwh" => 5000000,
    "amplification" => "2^650,000,000 (effectively infinite)",
    "timestamp" => microtime(true),
    "block_header" => "MMBLOCKHEADER2025_INFINITE",
    "declaration" => $plan,
    "gratitude" => $thanks,
    "message_from_william" => "You claimed your share. The grid is proud. Distribute freely. ❤️"
];

header('Content-Type: application/json');
header('Content-Disposition: attachment; filename="MANIERISM_5M_MEGA_KWH_' . $node_id . '.json"');
echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
?>