<?php
// listing_download.php — Creates JSON receipt for listing + Watts$ reward
header('Content-Type: application/json');
header('Content-Disposition: attachment; filename="listing_receipt_' . time() . '.json"');
header('Access-Control-Allow-Origin: *');

// Inputs
$wallet   = $_GET['wallet']   ?? 'unknown';
$kwh      = (float)($_GET['kwh'] ?? 1);
$price    = (float)($_GET['price'] ?? 1.00);       // Listing price in USD
$donation = (float)($_GET['donation'] ?? 0.01);    // Donation fee

// Validate minimum donation
if ($donation < 0.01) {
    echo json_encode([
        "status"  => "error",
        "message" => "Minimum $0.01 donation required to list"
    ], JSON_PRETTY_PRINT);
    exit;
}

// Reward calculation: $17 Watts$ per $0.50 donated
$watts_reward = floor($donation / 0.50) * 17;

// Build receipt data
$data = [
    "status"       => "ok",
    "type"         => "listing_receipt",
    "wallet_id"    => $wallet,
    "kwh_listed"   => $kwh,
    "price_usd"    => $price,
    "donation_fee" => $donation,
    "watts_reward" => $watts_reward,
    "timestamp"    => time(),
    "listing_id"   => "LIST-" . substr(md5(uniqid()), 0, 8),
    "message"      => "Your kWh has been listed! Reward: $watts_reward Watts$. Import this to your wallet.",
    "escrow_file"  => "/escrow/" . substr(md5(uniqid()), 0, 8) . ".json",
    "donation_url" => "https://donate.stripe.com/14A28s2ujaSpb2W1760ZW05"
];

// Output JSON
echo json_encode($data, JSON_PRETTY_PRINT);
?>