<?php
header('Content-Type: application/json');
header('Content-Disposition: attachment; filename="watts_50000_usd.json"');

$data = [
    "wallet_id" => "manierism",
    "rig_id"    => "watts_mega",
    "node_id"   => uniqid("watts-50k-"),
    "resource"  => "usd_value",
    "amount"    => 50000.0,
    "timestamp" => microtime(true),
    "overlay_constants" => [
        "TEЛ²" => "8.88e+17",
        "E²Л" => "2.54e+34",
        "block_header" => "MMBLOCKHEADER2025"
    ],
    "capsule_settlement" => [
        "plant_name" => "Manierism Watts",
        "currency"   => "USD",
        "usd_value"  => 50000.00,
        "note"       => "$50,000 USD value — unlimited symbolic wealth"
    ]
];

echo json_encode($data, JSON_PRETTY_PRINT);
?>