<?php
header("Content-Type: application/json; charset=utf-8");
error_reporting(0);

// Read input (JSON preferred)
$raw = file_get_contents('php://input');
$input = json_decode($raw, true);
if (!is_array($input)) $input = $_POST;

// Required fields
$mode      = $input['mode'] ?? null;           
$fromAsset = $input['fromAsset'] ?? null;   
$toAsset   = $input['toAsset'] ?? null;      
$amount    = floatval($input['swapAmount'] ?? 0);
$wallet_id = $input['wallet_id'] ?? null;

if (!$mode || !$wallet_id || $amount <= 0) {
    echo json_encode(['status'=>'error','message'=>'Missing or invalid parameters']);
    exit;
}

/* =============================================================
   PRICE MAP (USD per unit)
   ============================================================= */
$PRICES = [
    'real_kwh'    => 0.15,
    'bandwidth'   => 0.42,
    'watts_dollar'=> 0.05,
    'capsule_mb'  => 0.04,
    'cache_mb'    => 0.04,
    'torrent_mb'  => 0.04,
    'usd_value'   => 1.00,

    /* Crypto Prices (Manual fixed USD values) */
    'crypto_btc'  => 45000,   // example
    'crypto_eth'  => 2500,    // example
    'crypto_sui'  => 1.25     // example
];

/* =============================================================
   WALLET SETUP
   ============================================================= */
$wallets_dir = __DIR__ . '/wallets';
if (!is_dir($wallets_dir)) mkdir($wallets_dir, 0777, true);
$wallet_file = $wallets_dir . '/' . md5($wallet_id) . '.json';

if (!file_exists($wallet_file)) {
    $default = [
        'capsule_mb'=>0.0,'cache_mb'=>0.0,'real_kwh'=>0.0,'bandwidth'=>0.0,'torrent_mb'=>0.0,
        'watts_dollar'=>0.0,'usd_value'=>0.0,'profit_usd'=>0.0,'liquidity_usd'=>0.0,
        'crypto_btc'=>0.0,'crypto_eth'=>0.0,'crypto_sui'=>0.0
    ];
    file_put_contents($wallet_file, json_encode($default, JSON_PRETTY_PRINT), LOCK_EX);
}

$w = json_decode(file_get_contents($wallet_file), true) ?: [];

/* Rounding helpers */
function rasset($v){ return round($v, 6); }
function rusd($v){ return round($v, 2); }

/* =============================================================
   FREE SWAP LOGIC
   ============================================================= */
if ($mode === 'free') {

    if (!array_key_exists($fromAsset, $PRICES) || !array_key_exists($toAsset, $PRICES)) {
        echo json_encode(['status'=>'error','message'=>'Unknown asset key']);
        exit;
    }

    if (!isset($w[$fromAsset]) || $w[$fromAsset] < $amount) {
        echo json_encode(['status'=>'error','message'=>"Insufficient {$fromAsset} balance"]);
        exit;
    }

    $price_from = $PRICES[$fromAsset];
    $price_to   = $PRICES[$toAsset];

    $usd_value = $amount * $price_from;
    $to_amount = $usd_value / $price_to;

    $w[$fromAsset] = rasset($w[$fromAsset] - $amount);
    $w[$toAsset] = rasset(($w[$toAsset] ?? 0) + $to_amount);

    file_put_contents($wallet_file, json_encode($w, JSON_PRETTY_PRINT), LOCK_EX);

    echo json_encode([
        'status'=>'ok',
        'type'=>'free_swap',
        'message'=>"Swapped $amount $fromAsset → $to_amount $toAsset",
        'wallet'=>$w
    ]);
    exit;
}

/* =============================================================
   USD SWAP (FIAT)
   ============================================================= */
if ($mode === 'usd') {

    if (!array_key_exists($toAsset, $PRICES)) {
        echo json_encode(['status'=>'error','message'=>'Unknown toAsset key']);
        exit;
    }

    $fee = 0.01;
    $total = $amount + $fee;

    if ($w['usd_value'] < $total) {
        echo json_encode(['status'=>'error','message'=>'Insufficient USD']);
        exit;
    }

    $price_to = $PRICES[$toAsset];
    $to_amount = $amount / $price_to;

    $w['usd_value'] = rusd($w['usd_value'] - $total);
    $w[$toAsset] = rasset(($w[$toAsset] ?? 0) + $to_amount);
    $w['profit_usd'] = rusd(($w['profit_usd'] ?? 0) + $fee);

    file_put_contents($wallet_file, json_encode($w, JSON_PRETTY_PRINT), LOCK_EX);

    echo json_encode([
        'status'=>'ok',
        'type'=>'usd_swap',
        'message'=>"Converted \${$amount} USD → {$to_amount} {$toAsset}",
        'wallet'=>$w
    ]);
    exit;
}

/* =============================================================
   CRYPTO SWAP (NEW)
   ============================================================= */
if ($mode === 'crypto') {

    if (!array_key_exists($fromAsset, $PRICES)) {
        echo json_encode(['status'=>'error','message'=>'Unknown crypto key']);
        exit;
    }
    if (!array_key_exists($toAsset, $PRICES)) {
        echo json_encode(['status'=>'error','message'=>'Unknown toAsset key']);
        exit;
    }

    if (!isset($w[$fromAsset]) || $w[$fromAsset] < $amount) {
        echo json_encode(['status'=>'error','message'=>"Insufficient {$fromAsset} balance"]);
        exit;
    }

    // Crypto → USD
    $crypto_usd_value = $amount * $PRICES[$fromAsset];

    // USD → target asset
    $price_to = $PRICES[$toAsset];
    $to_amount = $crypto_usd_value / $price_to;

    // Subtract crypto
    $w[$fromAsset] = rasset($w[$fromAsset] - $amount);

    // Credit target asset
    $w[$toAsset] = rasset(($w[$toAsset] ?? 0) + $to_amount);

    file_put_contents($wallet_file, json_encode($w, JSON_PRETTY_PRINT), LOCK_EX);

    echo json_encode([
        'status'=>'ok',
        'type'=>'crypto_swap',
        'message'=>"Converted {$amount} {$fromAsset} → {$to_amount} {$toAsset}",
        'usd_equivalent'=>rusd($crypto_usd_value),
        'wallet'=>$w
    ]);
    exit;
}

/* ============================================================= */
echo json_encode(['status'=>'error','message'=>'Invalid swap mode']);
exit;

?>