<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=UTF-8');

$file = __DIR__ . '/balances.json';
if (!file_exists($file)) { echo json_encode(["status"=>"error","message"=>"Balances file missing"]); exit; }

$balances = json_decode(file_get_contents($file), true);

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!is_array($data)) { echo json_encode(["status"=>"error","message"=>"Invalid JSON"]); exit; }

foreach ($data as $k=>$v) {
  if (is_numeric($v)) { $balances[$k] = ($balances[$k] ?? 0) + (float)$v; }
}

file_put_contents($file, json_encode($balances, JSON_PRETTY_PRINT));
echo json_encode(["status"=>"ok","balances"=>$balances], JSON_PRETTY_PRINT);
