<?php
// pending_txs.php - List user's pending TXs (for display)
header('Content-Type: application/json; charset=utf-8');

$pending_file = __DIR__ . '/pending_txs.json'; // Store unverified TXs

$input = $_GET;
$wallet_id = $input['wallet_id'] ?? null;

if (!$wallet_id) {
    echo json_encode(['status' => 'error', 'message' => 'Missing wallet_id']);
    exit;
}

$pendings = file_exists($pending_file) ? json_decode(file_get_contents($pending_file), true) : [];
$user_pendings = array_filter($pendings, fn($p) => $p['wallet_id'] === $wallet_id && $p['status'] === 'pending');

echo json_encode([
    'status' => 'ok',
    'pending' => count($user_pendings),
    'list' => array_values($user_pendings) // Optional: show list
]);
?>