<?php
// buy_escrow.php — BUY FROM ESCROW → SEND TO SELLER

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=UTF-8');

$escrow_dir  = __DIR__ . '/escrow';
$wallets_dir = __DIR__ . '/wallets';
$ledger_file = __DIR__ . '/ledger.json';

$data = json_decode(file_get_contents('php://input'), true);
$listing_id = $data['listing_id'] ?? null;
$buyer_id   = $data['buyer_wallet_id'] ?? null;

if (!$listing_id || !$buyer_id) {
    echo json_encode(['status' => 'error', 'message' => 'Missing data']);
    exit;
}

$escrow_file = $escrow_dir . '/' . $listing_id . '.json';
if (!file_exists($escrow_file)) {
    echo json_encode(['status' => 'error', 'message' => 'Listing not found']);
    exit;
}

$listing = json_decode(file_get_contents($escrow_file), true);
if ($listing['status'] !== 'active') {
    echo json_encode(['status' => 'error', 'message' => 'Already sold']);
    exit;
}

$seller_id = $listing['seller_id'];
$kwh = $listing['kwh'];
$price = $listing['price_usd'];

// Give kWh to buyer
$buyer_file = $wallets_dir . '/' . md5($buyer_id) . '.json';
$buyer = file_exists($buyer_file) ? json_decode(file_get_contents($buyer_file), true) : ['real_kwh' => 0];
$buyer['real_kwh'] = ($buyer['real_kwh'] ?? 0) + $kwh;
file_put_contents($buyer_file, json_encode($buyer, JSON_PRETTY_PRINT));

// Pay seller
$seller_file = $wallets_dir . '/' . md5($seller_id) . '.json';
$seller = json_decode(file_get_contents($seller_file), true);
$seller['usd_value'] += $price;
$seller['profit_usd'] += $price;
file_put_contents($seller_file, json_encode($seller, JSON_PRETTY_PRINT));

// Mark as sold
$listing['status'] = 'sold';
$listing['buyer_id'] = $buyer_id;
$listing['sold_at'] = time();
file_put_contents($escrow_file, json_encode($listing, JSON_PRETTY_PRINT));

// Log
$ledger = file_exists($ledger_file) ? json_decode(file_get_contents($ledger_file), true) : [];
$ledger[] = [
    'type' => 'escrow_sold',
    'listing_id' => $listing_id,
    'buyer' => $buyer_id,
    'seller' => $seller_id,
    'kwh' => $kwh,
    'usd' => $price,
    'timestamp' => time()
];
file_put_contents($ledger_file, json_encode($ledger, JSON_PRETTY_PRINT));

echo json_encode([
    'status' => 'ok',
    'message' => "BOUGHT! {$kwh} kWh sent to buyer, \${$price} to seller"
]);
?>