<?php
date_default_timezone_set('UTC');

// Configuration for Megabytes Purchase
$AMOUNT_PER_DOWNLOAD_MBS = 50000.0; 
$BALANCE_FILE = __DIR__ . '/balance.json';
$LEDGER_FILE  = __DIR__ . '/ledger/mb_events.log'; // Resource-specific ledger
$RECEIPTS_DIR = __DIR__ . '/mb_receipts'; // Resource-specific receipts
$PAID_COUNT_FILE = __DIR__ . '/mb_paid_count.txt'; // Resource-specific counter

// Setup directories
if (!is_dir($RECEIPTS_DIR)) mkdir($RECEIPTS_DIR, 0775, true);
if (!is_dir(dirname($LEDGER_FILE))) mkdir(dirname($LEDGER_FILE), 0775, true);

// --- 1. Lock, Read, and Validate Balance ---
$fp = fopen($BALANCE_FILE, 'c+');
if (!$fp || !flock($fp, LOCK_EX)) { http_response_code(500); exit("Balance file error/lock failed"); }

$balance = json_decode(stream_get_contents($fp), true) ?? [];
$remaining_amount = $balance['remaining_megabytes'] ?? 0;

if ($remaining_amount < $AMOUNT_PER_DOWNLOAD_MBS) {
  flock($fp, LOCK_UN); fclose($fp);
  http_response_code(409);
  exit("Insufficient balance for 50000 Megabytes. Remaining: " . $remaining_amount); 
}

// --- 2. Perform Deduction and Update Balance ---
$balance['remaining_megabytes'] -= $AMOUNT_PER_DOWNLOAD_MBS;
$balance['last_updated'] = gmdate("c");

ftruncate($fp, 0); rewind($fp);
fwrite($fp, json_encode($balance, JSON_PRETTY_PRINT)); 
fflush($fp); flock($fp, LOCK_UN); fclose($fp);

// --- 3. Update Paid Count ---
$currentCount = 0;
if (file_exists($PAID_COUNT_FILE)) {
    $currentCount = (int)file_get_contents($PAID_COUNT_FILE);
}
file_put_contents($PAID_COUNT_FILE, $currentCount + 1);

// --- 4. Generate Receipt & Log Ledger Entry ---
$receiptId = bin2hex(random_bytes(8));
$capsule = [
  "resource" => "megabytes_symbol", "amount" => $AMOUNT_PER_DOWNLOAD_MBS,
  // ... (other metadata) ...
  "receipt_meta" => ["receipt_id" => $receiptId, "issued_at" => gmdate("c"), "source" => "Symbolic Megabytes Purchase"]
];
file_put_contents($RECEIPTS_DIR . "/receipt_" . $receiptId . ".json", json_encode($capsule, JSON_PRETTY_PRINT));

$ledgerEntry = [
  "type" => "symbolic_megabytes_download", "amount" => $AMOUNT_PER_DOWNLOAD_MBS,
  "remaining_balance" => $balance['remaining_megabytes'], "receipt_id" => $receiptId,
  "ip" => $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN'
];
file_put_contents($LEDGER_FILE, json_encode($ledgerEntry) . "\n", FILE_APPEND | LOCK_EX);

// --- 5. Send Download ---
header('Content-Type: application/json');
header('Content-Disposition: attachment; filename="paid_50000_mbs_' . $receiptId . '.json"'); 
echo json_encode($capsule, JSON_PRETTY_PRINT);
exit;
?>