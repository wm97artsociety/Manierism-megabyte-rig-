<?php
header('Content-Type: application/json');
header('Content-Disposition: attachment; filename="data_1_mbps_free.json"');

$data = [
    "wallet_id" => "manierism",
    "rig_id"    => "data_faucet",
    "node_id"   => uniqid("data-free-"),
    "resource"  => "bandwidth_MBps",
    "amount"    => 100.0,
    "timestamp" => microtime(true),
    "overlay_constants" => [
        "TEЛ²" => "8.88e+17",
        "E²Л" => "2.54e+34",
        "block_header" => "MMBLOCKHEADER2025"
    ],
    "capsule_settlement" => [
        "plant_name" => "Manierism Data Center",
        "currency"   => "MBps",
        "value"      => "100 MB/s perpetual",
        "note"       => "Free 100 MB/s — unlimited — pure bandwidth"
    ]
];

echo json_encode($data, JSON_PRETTY_PRINT);
?>