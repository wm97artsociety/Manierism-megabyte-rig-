<?php
// import_balance.php — FINAL BULLETPROOF VERSION
// Works on ANY server — no network errors — adds to balances

// Prevent any output before headers
ob_start();
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=UTF-8');

// === CRITICAL: Make sure folders exist ===
$wallets_dir = __DIR__ . '/wallets';
$used_dir    = __DIR__ . '/used_imports';

if (!is_dir($wallets_dir) && !mkdir($wallets_dir, 0755, true)) {
    ob_end_clean();
    echo json_encode(['status' => 'error', 'message' => 'Cannot create wallets folder']);
    exit;
}
if (!is_dir($used_dir) && !mkdir($used_dir, 0755, true)) {
    ob_end_clean();
    echo json_encode(['status' => 'error', 'message' => 'Cannot create used_imports folder']);
    exit;
}

// === Check upload ===
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_FILES['importFile']) || $_FILES['importFile']['error'] !== UPLOAD_ERR_OK) {
    ob_end_clean();
    echo json_encode(['status' => 'error', 'message' => 'Upload failed or no file']);
    exit;
}

$tmp_file = $_FILES['importFile']['tmp_name'];
$content = @file_get_contents($tmp_file);

if ($content === false || $content === '') {
    @unlink($tmp_file);
    ob_end_clean();
    echo json_encode(['status' => 'error', 'message' => 'Cannot read uploaded file']);
    exit;
}

$data = json_decode($content, true);
if (!is_array($data)) {
    @unlink($tmp_file);
    ob_end_clean();
    echo json_encode(['status' => 'error', 'message' => 'Invalid JSON']);
    exit;
}

// === Get wallet_id ===
$wallet_id = $data['wallet_id'] ?? $data['rig_id'] ?? $data['node_id'] ?? null;
if (!$wallet_id) {
    @unlink($tmp_file);
    ob_end_clean();
    echo json_encode(['status' => 'error', 'message' => 'No wallet_id found']);
    exit;
}

// === One-time use check ===
$timestamp = $data['export_timestamp'] ?? $data['timestamp'] ?? time();
$hash = md5($wallet_id . $timestamp);
$used_file = $used_dir . '/' . $hash;

if (file_exists($used_file)) {
    @unlink($tmp_file);
    ob_end_clean();
    echo json_encode(['status' => 'error', 'message' => 'This backup has already been used!']);
    exit;
}

// === Extract balances to ADD ===
$add = [
    'real_kwh'     => 0.0,
    'watts_dollar' => 0.0,
    'usd_value'    => 0.0,
    'profit_usd'   => 0.0
];

// Full backup
if (isset($data['balances']) && is_array($data['balances'])) {
    foreach ($add as $key => &$val) {
        if (isset($data['balances'][$key])) $val = (float)$data['balances'][$key];
    }
}
// Legacy formats
else {
    if (isset($data['amount'])) {
        $add['real_kwh'] = is_numeric($data['amount']) ? (float)$data['amount'] : 0;
        if (is_string($data['amount']) && preg_match('/^[\deE\+\-\.]+$/', $data['amount'])) {
            $add['real_kwh'] = (float)$data['amount'];
        }
    }
    if (isset($data['amount_transferred'])) {
        $add['real_kwh'] = (float)preg_replace('/[^\d\.eE+-]/', '', $data['amount_transferred']);
    }
}

// === Load current wallet ===
$user_file = $wallets_dir . '/' . md5($wallet_id) . '.json';
$current = ['real_kwh' => 0.0, 'watts_dollar' => 0.0, 'usd_value' => 0.0, 'profit_usd' => 0.0];

if (file_exists($user_file)) {
    $current = json_decode(file_get_contents($user_file), true) ?: $current;
}

// === ADD imported values ===
foreach ($add as $key => $value) {
    $current[$key] = (float)($current[$key] ?? 0) + $value;
}
$current['last_updated'] = gmdate('c');

// === Save and mark as used ===
file_put_contents($user_file, json_encode($current, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
@chmod($user_file, 0666);

file_put_contents($used_file, $wallet_id . ' @ ' . date('c'));
@chmod($used_file, 0666);

@unlink($tmp_file);

ob_end_clean();
echo json_encode([
    'status'       => 'ok',
    'message'      => 'SUCCESS! Balances added to your wallet',
    'wallet_id'    => $wallet_id,
    'added_kwh'    => number_format($add['real_kwh'], 0),
    'new_total'    => number_format($current['real_kwh'], 0)
], JSON_PRETTY_PRINT);
?>