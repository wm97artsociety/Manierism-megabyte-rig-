<?php
header('Content-Type: application/json');

// --- Database connection configuration ---
// Using the credentials found in your uploaded files
$servername = "";
$username   = "";
$password   = ""; 
$dbname     = "";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["error" => "DB connection failed: " . $conn->connect_error]));
}

// --- Update Data for 1 Kilowatt Product ---
$targetProductName = "1 Free Kilowatt Digital Battery Test Kit"; 
$newImagePath      = "electrism.jpg"; // Set to the desired file name

// Prepare and execute the UPDATE statement
$stmt = $conn->prepare("UPDATE products SET imageUrl = ? WHERE name = ?");
$stmt->bind_param("ss", $newImagePath, $targetProductName);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        $response = ["success" => true, "message" => "Image path for '{$targetProductName}' successfully updated to '{$newImagePath}' in the database, just like the 100 KWh product."];
    } else {
        $response = ["success" => true, "message" => "Product '{$targetProductName}' not found or image path was already correct. (No change needed)."];
    }
} else {
    $response = ["error" => "Error executing update: " . $stmt->error];
}

$stmt->close();
$conn->close();

echo json_encode($response);
?>