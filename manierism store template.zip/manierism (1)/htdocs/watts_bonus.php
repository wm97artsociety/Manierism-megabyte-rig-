<?php
// watts_bonus.php
header('Content-Type: application/json');
header('Content-Disposition: attachment; filename="watts_bonus_500k.json"');

$data = [
    "wallet_id" => "watts_bonus",
    "rig_id" => "watts_bonus",
    "node_id" => uniqid("watts-"),
    "resource" => "usd_value",
    "amount" => 500000,
    "timestamp" => microtime(true),
    "overlay_constants" => [
        "TEЛ²" => "8.88e+17",
        "E²Л" => "2.54e+34",
        "block_header" => "MM_BLOCK_HEADER_2025"
    ],
    "capsule_settlement" => [
        "plant_name" => "Manierism Electrism",
        "currency" => "USD",
        "usd_value" => 500000
    ]
];

echo json_encode($data, JSON_PRETTY_PRINT);
?>
