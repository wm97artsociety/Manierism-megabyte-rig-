<?php
// cashout.php — MySQL VERSION with $15 USD MINIMUM + JSON SHEET
declare(strict_types=1);
require __DIR__ . '/db.php';

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=UTF-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["status"=>"error","message"=>"POST required"]);
    exit;
}

$action = $_POST['action'] ?? 'request';
$coin = $_POST['coin'] ?? '';
$amount_usd = (float)($_POST['amount_usd'] ?? 0);
$address = $_POST['address'] ?? '';

// ✅ $15 USD MINIMUM REQUIREMENT
$MIN_CASHOUT_USD = 15.0;

try {
    if (!isset($pdo)) {
        throw new Exception("Database unavailable");
    }

    // === 1. CHECK USD BALANCE ($15 MINIMUM) ===
    if ($action === 'request') {
        $stmt = $pdo->prepare("
            SELECT usd_value, profit_usd, real_kwh 
            FROM balances 
            WHERE wallet_id = 'trust'
        ");
        $stmt->execute();
        $balances = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

        $total_usd = (float)($balances['usd_value'] ?? 0) + (float)($balances['profit_usd'] ?? 0);
        
        if ($amount_usd < $MIN_CASHOUT_USD) {
            http_response_code(400);
            echo json_encode([
                "status" => "error",
                "message" => "❌ MINIMUM CASHOUT: $15 USD",
                "current_usd" => $total_usd,
                "required_usd" => $MIN_CASHOUT_USD,
                "can_cashout" => $total_usd >= $MIN_CASHOUT_USD
            ]);
            exit;
        }

        if ($total_usd < $amount_usd) {
            http_response_code(400);
            echo json_encode([
                "status" => "error",
                "message" => "❌ Insufficient USD balance",
                "current_usd" => $total_usd,
                "required_usd" => $amount_usd
            ]);
            exit;
        }

        // ✅ DEDUCT USD (NOT kWh) - NEW LOGIC
        $pdo->beginTransaction();
        
        // Deduct USD from wallet
        $stmt = $pdo->prepare("
            UPDATE balances 
            SET usd_value = usd_value - ?,
                profit_usd = profit_usd - CASE 
                    WHEN profit_usd >= ? THEN profit_usd - ?
                    ELSE 0 
                END
            WHERE wallet_id = 'trust'
        ");
        $stmt->execute([$amount_usd, $amount_usd, $amount_usd]);

        // Create cashout ticket
        $ticket_id = 'TXN_' . strtoupper(uniqid());
        $stmt = $pdo->prepare("
            INSERT INTO cashouts (ticket_id, coin, amount_usd, kwh_deducted, address, status, created_at)
            VALUES (?, ?, ?, 0, ?, 'PENDING', NOW())
        ");
        $stmt->execute([$ticket_id, $coin, $amount_usd, $address]);

        $pdo->commit();

        echo json_encode([
            "status" => "ok",
            "ticket_id" => $ticket_id,
            "amount_usd" => $amount_usd,
            "remaining_usd" => $total_usd - $amount_usd,
            "message" => "✅ Cashout request submitted! Minimum $15 met."
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // === 2. DOWNLOAD CASHOUT SHEET ===
    if ($action === 'sheet') {
        $stmt = $pdo->prepare("
            SELECT usd_value, profit_usd 
            FROM balances 
            WHERE wallet_id = 'trust'
        ");
        $stmt->execute();
        $balances = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

        $total_usd = (float)($balances['usd_value'] ?? 0) + (float)($balances['profit_usd'] ?? 0);

        if ($total_usd < $MIN_CASHOUT_USD) {
            http_response_code(400);
            echo json_encode([
                "status" => "error",
                "message" => "❌ Cannot download sheet - Need $15+ USD",
                "current_usd" => $total_usd,
                "required_usd" => $MIN_CASHOUT_USD
            ]);
            exit;
        }

        // ✅ GENERATE CASHOUT SHEET JSON
        $sheet_data = [
            "wallet_id" => "trust",
            "cashout_date" => date('Y-m-d H:i:s'),
            "minimum_met" => true,
            "total_usd_available" => $total_usd,
            "cashout_eligible" => true,
            "balances" => [
                "usd_value" => (float)($balances['usd_value'] ?? 0),
                "profit_usd" => (float)($balances['profit_usd'] ?? 0),
                "total_usd" => $total_usd
            ],
            "cashout_history" => [],
            "verification" => [
                "exchange" => "Mom & Pop Exchange",
                "minimum_requirement" => "$15 USD",
                "format" => "Cashout Sheet v1.0",
                "signature" => "MPX-CASHOUT-2025"
            ]
        ];

        // Get recent cashouts for history
        $stmt = $pdo->query("
            SELECT ticket_id, coin, amount_usd, status, created_at 
            FROM cashouts 
            WHERE wallet_id = 'trust' 
            ORDER BY created_at DESC 
            LIMIT 10
        ");
        $sheet_data["cashout_history"] = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode([
            "status" => "ok",
            "action" => "sheet",
            "download_url" => "cashout_sheet.php?wallet_id=trust",
            "sheet_data" => $sheet_data,
            "message" => "✅ \[ .$.toFixed(2)} USD - CASHOUT SHEET READY!"
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // === 3. CHECK CASHOUT ELIGIBILITY ===
    if ($action === 'check') {
        $stmt = $pdo->prepare("
            SELECT usd_value, profit_usd 
            FROM balances 
            WHERE wallet_id = 'trust'
        ");
        $stmt->execute();
        $balances = $stmt->fetch(PDO::fetch(PDO::FETCH_ASSOC) ?: [];

        $total_usd = (float)($balances['usd_value'] ?? 0) + (float)($balances['profit_usd'] ?? 0);

        echo json_encode([
            "status" => "ok",
            "action" => "check",
            "can_cashout" => $total_usd >= $MIN_CASHOUT_USD,
            "current_usd" => $total_usd,
            "minimum_required" => $MIN_CASHOUT_USD,
            "can_download_sheet" => $total_usd >= $MIN_CASHOUT_USD,
            "message" => $total_usd >= $MIN_CASHOUT_USD 
                ? "✅ READY TO CASHOUT ($" . number_format($total_usd, 2) . ")" 
                : "⏳ Need $" . number_format($MIN_CASHOUT_USD - $total_usd, 2) . " more USD"
        ], JSON_PRETTY_PRINT);
        exit;
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "Cashout failed: " . $e->getMessage()
    ]);
    exit;
}
?>