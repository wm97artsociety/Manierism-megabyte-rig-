<?php
// sell_stocks.php - Deducts KWH, requests PENDING USD payout, and logs trade.
declare(strict_types=1);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// --- Configuration ---
define('KWH_USD_RATE', 0.0015);
define('WATTS_DOLLAR_MULTIPLIER', 34.0);
$apiKey = "";
$walletId = $_POST['wallet_id'] ?? 'trust'; // 'trust' is the default ID

$balances_file       = __DIR__ . '/balances.json';
$log_file            = __DIR__ . '/trades_log.json';
$orders_file         = __DIR__ . '/orders.json';
// NEW: File to track pending payments to be sent via external API
$payout_requests_file = __DIR__ . '/payout_requests.json'; 

// --- Helper Functions ---
function sendError(string $message, int $status_code = 400): void {
    http_response_code($status_code);
    echo json_encode(["status" => "error", "message" => $message]);
    exit();
}

/**
 * Atomically updates the balances.json file using an exclusive file lock (LOCK_EX).
 */
function updateBalances(string $file, array $updates): bool {
    $fp = fopen($file, 'c+');
    if (!$fp) return false;
    if (flock($fp, LOCK_EX)) {
        // Read existing content
        $data = stream_get_contents($fp, -1, 0);
        $balances = json_decode($data, true) ?? [];
        // Merge updates
        $balances = array_merge($balances, $updates);
        // Write back
        ftruncate($fp, 0);
        rewind($fp);
        $result = fwrite($fp, json_encode($balances, JSON_PRETTY_PRINT));
        flock($fp, LOCK_UN);
        fclose($fp);
        return $result !== false;
    }
    fclose($fp);
    return false;
}

/**
 * Atomically logs a new order to the orders.json file (for the live order book).
 */
function logOrder(string $file, array $order): bool {
    $fp = fopen($file, 'c+');
    if (!$fp) return false;
    if (flock($fp, LOCK_EX)) {
        $data = stream_get_contents($fp, -1, 0);
        $orders = json_decode($data, true) ?? [];
        $orders[] = $order;
        ftruncate($fp, 0);
        rewind($fp);
        $result = fwrite($fp, json_encode($orders, JSON_PRETTY_PRINT));
        flock($fp, LOCK_UN);
        fclose($fp);
        return $result !== false;
    }
    fclose($fp);
    return false;
}

/**
 * Logs a request for a payout to the payout_requests_file.
 * This simulates a record of USD that needs to be paid out externally.
 */
function logPayoutRequest(string $file, array $request): bool {
    $fp = fopen($file, 'c+');
    if (!$fp) return false;
    if (flock($fp, LOCK_EX)) {
        $data = stream_get_contents($fp, -1, 0);
        $requests = json_decode($data, true) ?? [];
        $requests[] = $request;
        ftruncate($fp, 0);
        rewind($fp);
        $result = fwrite($fp, json_encode($requests, JSON_PRETTY_PRINT));
        flock($fp, LOCK_UN);
        fclose($fp);
        return $result !== false;
    }
    fclose($fp);
    return false;
}
// --- End Helper Functions ---

$data = $_POST;

// 1. Validate input (Assuming 'count' from stock.html's 'sellCount' is the number of trades)
$tradeCount = isset($data['count']) ? (float)$data['count'] : 1.0;
if (!is_numeric($tradeCount) || $tradeCount <= 0) {
    sendError("Invalid trade count.");
}

// 2. Calculate trade values (Assuming 100 KWH is sold per trade for $0.50 USD)
$kwhDeductedPerTrade = 100.0;
$usdPerTrade         = 0.50;
$totalKwhDeducted    = $tradeCount * $kwhDeductedPerTrade;
$totalUsdPayout      = $tradeCount * $usdPerTrade;
$wattsDollarCredit   = round($totalUsdPayout * WATTS_DOLLAR_MULTIPLIER, 4);

// 3. Load current balances
$currentBalances = json_decode(file_get_contents($balances_file) ?? '[]', true) ?? [];
$currentKwh = $currentBalances['real_kwh'] ?? 0.0;

// 4. Check balance
if ($currentKwh < $totalKwhDeducted) {
    sendError("Insufficient Real kWh balance. Required: {$totalKwhDeducted}, Available: {$currentKwh}", 403);
}

// 5. Perform balance update (Atomic operation)
// *** IMPORTANT FIX: USD IS NOT CREDITED HERE. IT IS LOGGED AS A PENDING PAYOUT. ***
$updates = [
    'real_kwh'     => $currentKwh - $totalKwhDeducted,
    // usd_value and profit_usd are NOT credited here.
    'watts_dollar' => ($currentBalances['watts_dollar'] ?? 0.0) + $wattsDollarCredit
];

if (!updateBalances($balances_file, $updates)) {
    sendError("Failed to deduct KWH and update Watts Dollar atomically.", 500);
}

// 6. Log the sell order to orders.json (for live order book)
$orderLog = [
    'type' => 'SELL',
    'wallet_id' => $walletId,
    'usd_amount' => $usdPerTrade,
    'watts_dollar' => $wattsDollarCredit / $tradeCount,
    'kwh_amount' => $kwhDeductedPerTrade,
    'trade_count' => $tradeCount,
    'created_at' => date('Y-m-d H:i:s')
];
logOrder($orders_file, $orderLog);

// 7. Log Payout Request (Simulates sending the request to the external payment API)
$payoutRequest = [
    'payout_id' => uniqid('PAYOUT_'),
    'wallet_id' => $walletId,
    'amount_usd' => $totalUsdPayout,
    'kwh_source' => $totalKwhDeducted,
    'status' => 'PENDING_PAYOUT', // Must be paid out by an external process/API confirmation
    'request_time' => date('Y-m-d H:i:s')
];
logPayoutRequest($payout_requests_file, $payoutRequest);

// 8. Respond
echo json_encode([
    "status" => "ok",
    "message" => "Successfully deducted {$totalKwhDeducted} Real kWh. Your \${$totalUsdPayout} payout has been requested (Ticket ID: {$payoutRequest['payout_id']}) and is now **PENDING** external API processing.",
    "kwh_deducted" => $totalKwhDeducted,
    "usd_payout_pending" => $totalUsdPayout,
    "watts_dollar_credited" => $wattsDollarCredit,
    "payout_ticket_id" => $payoutRequest['payout_id'],
    "balances" => array_merge($currentBalances, $updates)
]);
exit();