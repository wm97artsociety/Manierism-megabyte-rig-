<?php
session_start();
$wallet = $_SESSION['donation_wallet'] ?? null;
unset($_SESSION['donation_wallet']);
if (!$wallet) { header("Location: stock.html"); exit; }

$wallets = json_decode(file_get_contents('data/wallets.json'), true) ?? [];
$wallets[$wallet]['watts'] = ($wallets[$wallet]['watts'] ?? 0) + 17;
file_put_contents('data/wallets.json', json_encode($wallets, JSON_PRETTY_PRINT));

$rid = 'DONATE-'.strtoupper(dechex(time()));
header('Content-Type: application/json');
header('Content-Disposition: attachment; filename="WattsReceipt_'.$rid.'.json"');
echo json_encode([
  "receipt_id" => $rid,
  "action" => "Donation Reward",
  "timestamp_utc" => gmdate("Y-m-d H:i:s")." UTC",
  "wallet_id" => $wallet,
  "donation_usd" => 0.50,
  "watts_received" => 17
], JSON_PRETTY_PRINT);
exit;