<?php
// save_stock.php — save a stock/coin symbol into DB
declare(strict_types=1);
require __DIR__ . '/db.php';

header('Content-Type: application/json; charset=UTF-8');

// --- Helper for errors ---
function sendError(string $message, int $status_code = 400): void {
    http_response_code($status_code);
    echo json_encode(["status" => "error", "message" => $message]);
    exit();
}

// --- Collect and validate inputs ---
$symbol = strtoupper(trim($_POST['symbol'] ?? ''));
$name   = trim($_POST['name'] ?? '');
$price  = isset($_POST['price_usd']) ? (float)$_POST['price_usd'] : null;

if ($symbol === '') {
    sendError("Symbol required.");
}
if ($price === null || $price < 0) {
    sendError("Valid price_usd required.");
}

try {
    $stmt = $pdo->prepare("
        INSERT INTO tokens (symbol, name, price_usd)
        VALUES (:symbol, :name, :price)
        ON DUPLICATE KEY UPDATE
          name = VALUES(name),
          price_usd = VALUES(price_usd)
    ");
    $stmt->execute([
        ':symbol' => $symbol,
        ':name'   => $name,
        ':price'  => $price
    ]);

    echo json_encode([
        "status"  => "ok",
        "message" => "Stock saved successfully",
        "symbol"  => $symbol,
        "name"    => $name,
        "price"   => $price
    ]);
} catch (PDOException $e) {
    sendError("Database error: " . $e->getMessage(), 500);
}
