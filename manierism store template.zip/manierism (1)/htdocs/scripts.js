// Function to toggle the product details visibility
function toggleDetails(detailsId, arrowId) {
    const details = document.getElementById(detailsId);
    const arrow = document.getElementById(arrowId);
    
    // Check if the section is currently open (visible)
    const isVisible = details.classList.contains('visible');

    // Close all other detail sections before opening the requested one
    document.querySelectorAll('.product-details').forEach(d => {
        if (d.id !== detailsId) {
            d.classList.remove('visible');
        }
    });
    document.querySelectorAll('.toggle-arrow').forEach(a => {
        if (a.id !== arrowId) {
            a.classList.remove('open');
        }
    });

    // Toggle the requested section/arrow
    if (!isVisible) {
        details.classList.add('visible');
        arrow.classList.add('open');
    } else {
        details.classList.remove('visible');
        arrow.classList.remove('open');
    }
}

// Conceptual function to load and update the download counters
function updateCounters() {
    // In a real setup, this would fetch data from a server endpoint
    
    // Simulate current download count for 1 kWh Faucet
    const faucetCount = Math.floor(Math.random() * 500) + 100;
    const salesCount = 47; // Static value for the 100 kWh product

    const count1kwh = document.getElementById('download-count-1kwh');
    if (count1kwh) {
        count1kwh.textContent = faucetCount.toLocaleString();
    }
    
    const count100kwh = document.getElementById('download-count-100kwh');
    if (count100kwh) {
        count100kwh.textContent = salesCount.toLocaleString();
    }
}

// Run the counter update when the page loads
document.addEventListener('DOMContentLoaded', updateCounters);