<?php
// --- IP Restriction Logic Start (1-Hour Cooldown) ---
// Log file for tracking download attempts. Ensure this file is writable by the server (e.g., CHMOD 666).
$log_file = 'download_watts_log.txt'; 
$cooldown_seconds = 3600; // 1 hour (60 minutes * 60 seconds)

// Function to get the real client IP address
function get_client_ip() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        // Handle proxies/load balancers, taking the first non-private IP
        $ip_list = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $ip = trim(end($ip_list));
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

$client_ip = get_client_ip();
$can_download = true;
$time_remaining = 0;

if (file_exists($log_file)) {
    // Read the log file line by line
    $log_content = file($log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    
    $last_download_time = 0;
    $new_log_entries = [];

    // Check existing entries and filter out old ones
    foreach ($log_content as $line) {
        // Expected format: [timestamp] [ip_address]
        @list($timestamp, $ip) = explode(' ', $line, 2);
        $timestamp = (int)$timestamp;
        
        // Keep logs for the cooldown period
        if (time() - $timestamp < $cooldown_seconds && $ip) {
            $new_log_entries[] = $line;
            if ($ip === $client_ip) {
                // Find the most recent download time for this IP
                $last_download_time = max($last_download_time, $timestamp);
            }
        }
    }

    if ($last_download_time > 0) {
        $elapsed = time() - $last_download_time;
        if ($elapsed < $cooldown_seconds) {
            $can_download = false;
            $time_remaining = $cooldown_seconds - $elapsed;
        }
    }
    
    // Rewrite the log file with only valid (recent) entries to prevent it from growing too large
    file_put_contents($log_file, implode("\n", $new_log_entries) . "\n");
}

if (!$can_download) {
    // DENIAL RESPONSE - Rate Limit Error
    http_response_code(429); // Too Many Requests
    header('Content-Type: application/json');
    header('Retry-After: ' . $time_remaining); // Inform client when to retry
    
    $minutes = floor($time_remaining / 60);
    $seconds = $time_remaining % 60;
    
    $error_data = [
        "status" => "error",
        "code" => 429,
        "message" => "Download limit reached. Please wait " . $minutes . " minutes and " . $seconds . " seconds before claiming again.",
        "cooldown_period_seconds" => $cooldown_seconds,
        "time_remaining_seconds" => $time_remaining
    ];
    
    echo json_encode($error_data, JSON_PRETTY_PRINT);
    exit;
}

// If we reach here, the download is allowed. Log the new download.
$log_entry = time() . ' ' . $client_ip . "\n";
file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);

// --- ARTIFACT DELIVERY (User's Specified Content) ---
header('Content-Type: application/json');
header('Content-Disposition: attachment; filename="watts_1_usd_free.json"');

$data = [
    "wallet_id" => "manierism",
    "rig_id"    => "watts_faucet",
    "node_id"   => uniqid("watts-free-"),
    "resource"  => "usd_value",
    "amount"    => 1.0,
    "timestamp" => microtime(true),
    "overlay_constants" => [
        "TEЛ²" => "8.88e+17",
        "E²Л" => "2.54e+34",
        "block_header" => "MMBLOCKHEADER2025"
    ],
    "capsule_settlement" => [
        "plant_name" => "Manierism Watts",
        "currency"   => "USD",
        "usd_value"  => 1.00,
        "note"       => "Free $1 USD value — unlimited — from the heart"
    ]
];

echo json_encode($data, JSON_PRETTY_PRINT);
?>