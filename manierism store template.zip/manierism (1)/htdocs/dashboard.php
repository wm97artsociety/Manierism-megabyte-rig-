<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // If JS from different domain; tighten in prod
session_start();
include 'config.php';
// include 'wallet_balances.php'; // Comment if deprecated—balances.json handles it now

$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    http_response_code(401);
    echo json_encode(['error' => 'Login required']);
    exit;
}

// Load per-user balances (fallback to global if per-user missing)
$balances_file = __DIR__ . "/balances_$user_id.json";
$balances = json_decode(file_exists($balances_file) ? file_get_contents($balances_file) : '{}', true);
if (empty($balances)) {
    $global_file = __DIR__ . '/balances.json'; // Legacy fallback
    $global = json_decode(file_exists($global_file) ? file_get_contents($global_file) : '{}', true);
    $balances = $global; // Or init defaults
}

// Fetch listings/escrows (from DB; assume $pdo from config)
$listings = $escrows = [];
try {
    $stmt = $pdo->prepare("SELECT id, item_name, price, status, created_at FROM listings WHERE user_id = ? AND status IN ('active', 'swapped') ORDER BY created_at DESC LIMIT 10");
    $stmt->execute([$user_id]);
    $listings = $stmt->fetchAll(PDO::FETCH_ASSOC); // Assoc for JS ease

    $stmt = $pdo->prepare("SELECT id, item_a, item_b, status, created_at FROM escrows WHERE user_a_id = ? OR user_b_id = ? ORDER BY created_at DESC LIMIT 5");
    $stmt->execute([$user_id, $user_id]);
    $escrows = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    error_log("Dashboard query failed: " . $e->getMessage());
    $listings = $escrows = [['error' => 'DB fetch failed']]; // Graceful degrade
}

// Recent trades (per-user log)
$log_file = __DIR__ . "/trades_log_$user_id.json";
$trades = file_exists($log_file) ? json_decode(file_get_contents($log_file), true) : [];
$recent_trades = array_slice(array_reverse($trades ?? []), 0, 5); // Newest first

// Unlock status
$profit = $balances['profit_usd'] ?? 0.0;
$unlocked = ($balances['feature_unlocked'] ?? false) && $profit >= 10.0;

echo json_encode([
    'success' => true,
    'user_id' => $user_id,
    'balances' => $balances,
    'listings' => $listings,
    'escrows' => $escrows,
    'recent_trades' => $recent_trades,
    'unlocked_usd_payout' => $unlocked,
    'profit_usd' => $profit, // Expose for UI calc ($8 per $10)
    'donation_url' => STRIPE_DONATION_URL
], JSON_PRETTY_PRINT); // Pretty for dev debugging
?>