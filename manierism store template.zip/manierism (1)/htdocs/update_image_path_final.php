<?php
// Set headers for JSON response
header('Content-Type: application/json');

// --- Database connection configuration (using credentials from your add_product.php) ---
$servername = "";
$username   = "";
$password   = ""; 
$dbname     = "";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["error" => "DB connection failed: " . $conn->connect_error]));
}

// --- Update Data ---
// Target the product based on its old name (assuming it's unique).
$targetProductName = "1 Free Kilowatt Digital Battery Test Kit";
$newImagePath      = "electrism.jpg"; // FIXED: Changed from "potato.jpg" to "electrism.jpg"

// Prepare and execute the UPDATE statement
$stmt = $conn->prepare("UPDATE products SET imageUrl = ? WHERE name = ?");
$stmt->bind_param("ss", $newImagePath, $targetProductName);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        // Success: Product was found and updated
        $response = ["success" => true, "message" => "Image path for '{$targetProductName}' permanently set to '{$newImagePath}' in the database."];
    } else {
        // Product not found or path was already correct
        $response = ["success" => true, "message" => "Product '{$targetProductName}' not found or image path was already '{$newImagePath}'. (No change needed)."];
    }
} else {
    // Execution failed
    $response = ["error" => "Error executing update: " . $stmt->error];
}

$stmt->close();
$conn->close();

echo json_encode($response);

?>