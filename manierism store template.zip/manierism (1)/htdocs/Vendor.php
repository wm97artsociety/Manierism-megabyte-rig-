<?php
// vendor.php — Vendor onboarding & wallet creation
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
require_once 'vendor/autoload.php';

$wallets_dir = __DIR__ . '/wallets';
if (!is_dir($wallets_dir)) mkdir($wallets_dir, 0755, true);

$data = json_decode(file_get_contents('php://input'), true);
$wallet_id = $data['wallet_id'] ?? null;

if (!$wallet_id) {
  echo json_encode(['status'=>'error','message'=>'Wallet ID required']);
  exit;
}

$wallet_file = $wallets_dir.'/'.md5($wallet_id).'.json';
if (file_exists($wallet_file)) {
  echo json_encode(['status'=>'ok','message'=>'Vendor already onboarded','wallet_id'=>$wallet_id]);
  exit;
}

// create wallet file
$wallet = [
  'wallet_id'=>$wallet_id,
  'real_kwh'=>0,
  'usd_value'=>0,
  'watts_dollar'=>0,
  'stripe_account_id'=>null
];
file_put_contents($wallet_file,json_encode($wallet,JSON_PRETTY_PRINT));

echo json_encode(['status'=>'ok','message'=>'Vendor onboarded','wallet_id'=>$wallet_id]);
?>