<?php
// listing.php — CREATE ESCROW LISTING WITH STRIPE CONNECT
// User locks kWh in escrow + pays $0.01+ fee → gets $17 Watts$ per $0.50 donated

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=UTF-8');

require_once 'vendor/autoload.php'; // Stripe PHP library

$wallets_dir = __DIR__ . '/wallets';
$escrow_dir  = __DIR__ . '/escrow';
$ledger_file = __DIR__ . '/ledger.json';

if (!is_dir($wallets_dir)) mkdir($wallets_dir, 0755, true);
if (!is_dir($escrow_dir))  mkdir($escrow_dir, 0755, true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'POST only']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$wallet_id   = $data['wallet_id']   ?? null;
$kwh         = (float)($data['kwh'] ?? 0);
$price_usd   = (float)($data['price_usd'] ?? 0);
$listing_fee = (float)($data['listing_fee'] ?? 0.01); // donation fee

// Validate inputs
if (!$wallet_id || $kwh <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid wallet or kWh']);
    exit;
}
if ($listing_fee < 0.01) {
    echo json_encode(['status' => 'error', 'message' => 'Minimum $0.01 donation required']);
    exit;
}

// Set Stripe key
\Stripe\Stripe::setApiKey('sk_live_xxx'); // replace with your real secret key

// Load wallet
$wallet_file = $wallets_dir . '/' . md5($wallet_id) . '.json';
if (!file_exists($wallet_file)) {
    echo json_encode(['status' => 'error', 'message' => 'Wallet not found']);
    exit;
}

$wallet = json_decode(file_get_contents($wallet_file), true);
if (($wallet['real_kwh'] ?? 0) < $kwh) {
    echo json_encode(['status' => 'error', 'message' => 'Not enough kWh']);
    exit;
}

// STRIPE CONNECT: Create/Retrieve Connected Account
$account_id = $wallet['stripe_account_id'] ?? null;
if (!$account_id) {
    $account = \Stripe\Account::create([
        'type' => 'standard',
        'country' => 'US',
        'email' => $wallet_id . '@marketplace.com',
        'capabilities' => [
            'card_payments' => ['requested' => true],
            'transfers'     => ['requested' => true],
        ],
    ]);
    $account_id = $account->id;

    $wallet['stripe_account_id'] = $account_id;
    file_put_contents($wallet_file, json_encode($wallet, JSON_PRETTY_PRINT));

    echo json_encode([
        'status' => 'ok',
        'message' => "Account created. Complete onboarding at Stripe.",
        'onboarding_url' => $account->url ?? null
    ]);
    exit;
}

// Deduct kWh from wallet (lock in escrow)
$wallet['real_kwh'] -= $kwh;
file_put_contents($wallet_file, json_encode($wallet, JSON_PRETTY_PRINT));

// Create escrow listing
$listing_id  = uniqid('LIST-');
$escrow_file = $escrow_dir . '/' . $listing_id . '.json';
$escrow_data = [
    'listing_id'    => $listing_id,
    'seller_id'     => $wallet_id,
    'seller_account'=> $account_id,
    'kwh'           => $kwh,
    'price_usd'     => $price_usd,
    'status'        => 'active',
    'created_at'    => time()
];
file_put_contents($escrow_file, json_encode($escrow_data, JSON_PRETTY_PRINT));

// Log to ledger
$ledger = file_exists($ledger_file) ? json_decode(file_get_contents($ledger_file), true) : [];
$ledger[] = [
    'type'        => 'listing_created',
    'listing_id'  => $listing_id,
    'wallet_id'   => $wallet_id,
    'kwh'         => $kwh,
    'price_usd'   => $price_usd,
    'listing_fee' => $listing_fee,
    'timestamp'   => time()
];
file_put_contents($ledger_file, json_encode($ledger, JSON_PRETTY_PRINT));

// Reward: $17 Watts$ per $0.50 donated
$watts_reward = floor($listing_fee / 0.50) * 17;
if ($watts_reward > 0) {
    $wallet['watts_dollar'] = ($wallet['watts_dollar'] ?? 0) + $watts_reward;
    file_put_contents($wallet_file, json_encode($wallet, JSON_PRETTY_PRINT));
}

// Final response
echo json_encode([
    'status'        => 'ok',
    'listing_id'    => $listing_id,
    'message'       => "Listed {$kwh} kWh for \${$price_usd}. Fee: \${$listing_fee}. Reward: {$watts_reward} Watts$",
    'watts_reward'  => $watts_reward,
    'stripe_account'=> $account_id,
    'donation_url'  => 'https://donate.stripe.com/14A28s2ujaSpb2W1760ZW05'
]);
?>