<?php
date_default_timezone_set('UTC');

// Config
$AMOUNT_PER_DOWNLOAD_WATTS_USD = 50000.0;
$BALANCE_FILE = __DIR__ . '/balance.json';
$LEDGER_FILE  = __DIR__ . '/ledger/events.log';
$RECEIPTS_DIR = __DIR__ . '/receipts';

// Ensure directories exist
if (!is_dir($RECEIPTS_DIR)) mkdir($RECEIPTS_DIR, 0775, true);
if (!is_dir(dirname($LEDGER_FILE))) mkdir(dirname($LEDGER_FILE), 0775, true);

// Lock balance file
$fp = fopen($BALANCE_FILE, 'c+');
if (!$fp) { http_response_code(500); exit("Balance file error"); }
if (!flock($fp, LOCK_EX)) { http_response_code(500); exit("Could not lock balance"); }

// Read balance
rewind($fp);
$raw = stream_get_contents($fp);
$balance = json_decode($raw, true);

// Initialize if missing
if (!is_array($balance)) $balance = [];
if (!isset($balance['remaining_watts_usd'])) $balance['remaining_watts_usd'] = 0;
if (!isset($balance['wallet_id'])) $balance['wallet_id'] = "william";
if (!isset($balance['rig_id'])) $balance['rig_id'] = "william";
if (!isset($balance['node_id'])) $balance['node_id'] = "eecd5cd6-90b5-4d0c-8f3b-0702aa4910bd";
if (!isset($balance['overlay_constants'])) {
    $balance['overlay_constants'] = [
        "TEЛ² constant" => "8.88 x 10¹⁷",
        "E²Л constant" => "2.54 x 10³⁴"
    ];
}
if (!isset($balance['capsule_settlement'])) {
    $balance['capsule_settlement'] = ["type" => "paid_symbolic"];
}

$remaining_amount = $balance['remaining_watts_usd'];

// Check funds
if ($remaining_amount < $AMOUNT_PER_DOWNLOAD_WATTS_USD) {
  flock($fp, LOCK_UN); fclose($fp);
  http_response_code(409);
  exit("Insufficient balance for 50000 Watts USD. Remaining: " . $remaining_amount);
}

// Deduct
$balance['remaining_watts_usd'] -= $AMOUNT_PER_DOWNLOAD_WATTS_USD;
$balance['last_updated'] = gmdate("c");

// Save balance
ftruncate($fp, 0); rewind($fp);
fwrite($fp, json_encode($balance, JSON_PRETTY_PRINT));
fflush($fp); flock($fp, LOCK_UN); fclose($fp);

// Build receipt
$receiptId = bin2hex(random_bytes(8));
$timestampUnix = microtime(true);

$capsule = [
  "wallet_id" => $balance['wallet_id'],
  "rig_id" => $balance['rig_id'],
  "node_id" => $balance['node_id'],
  "resource" => "watts_usd_symbol",
  "amount" => $AMOUNT_PER_DOWNLOAD_WATTS_USD,
  "timestamp" => $timestampUnix,
  "overlay_constants" => $balance['overlay_constants'],
  "capsule_settlement" => $balance['capsule_settlement'],
  "receipt_meta" => [
    "receipt_id" => $receiptId,
    "issued_at" => gmdate("c"),
    "source" => "Symbolic Watts USD Purchase"
  ]
];

// Save receipt
$receiptPath = $RECEIPTS_DIR . "/receipt_" . $receiptId . ".json";
file_put_contents($receiptPath, json_encode($capsule, JSON_PRETTY_PRINT));

// Append ledger
$ledgerEntry = [
  "type" => "symbolic_watts_usd_download",
  "timestamp" => gmdate("c"),
  "amount" => $AMOUNT_PER_DOWNLOAD_WATTS_USD,
  "remaining_balance" => $balance['remaining_watts_usd'],
  "receipt_id" => $receiptId,
  "ip" => $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN'
];
file_put_contents($LEDGER_FILE, json_encode($ledgerEntry) . "\n", FILE_APPEND | LOCK_EX);

// Output
header('Content-Type: application/json');
header('Content-Disposition: attachment; filename="paid_50k_watts_usd_' . $receiptId . '.json"');
echo json_encode($capsule, JSON_PRETTY_PRINT);
exit;
?>
