<?php
// wallet_update.php — FIXED MERGE VERSION
header('Content-Type: application/json');

// Prevent warnings from breaking JSON
error_reporting(0);
ini_set('display_errors', 0);

// File location
$balances_file = __DIR__ . "/balances.json";

// Load current balances
if (!file_exists($balances_file)) {
    echo json_encode(["status"=>"error","message"=>"balances.json missing"]);
    exit;
}

$currentBalances = json_decode(file_get_contents($balances_file), true);
if (!is_array($currentBalances)) $currentBalances = [];

// Read Stripe webhook payload
$input = file_get_contents("php://input");
$event = json_decode($input, true);

if (!$event || !isset($event["type"])) {
    echo json_encode(["status"=>"error","message"=>"Invalid event"]);
    exit;
}

if ($event["type"] === "charge.succeeded") {

    // Convert cents to USD
    $usdAmount = floatval($event["data"]["object"]["amount"] / 100);

    // MERGE logic — add to USD but keep all swap.php data
    $currentBalances["usd_value"] = 
        ($currentBalances["usd_value"] ?? 0) + $usdAmount;

    // Save merged balances
    file_put_contents($balances_file, json_encode($currentBalances, JSON_PRETTY_PRINT));

    echo json_encode([
        "status" => "ok",
        "message" => "Deposit added",
        "balances" => $currentBalances
    ]);
    exit;
}

// Default JSON response
echo json_encode(["status"=>"ok","event"=>$event["type"]]);
exit;
?>