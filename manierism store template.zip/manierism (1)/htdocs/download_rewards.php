<?php
// download_rewards.php — export user rewards into various file formats
// Logs debit/credit transaction to wallet_balances_log.json

header("Access-Control-Allow-Origin: *");

// --- Configuration ---
$log_file     = __DIR__ . '/wallet_balances_log.json';
$walletId     = 'trust';     // Fixed ID for consistency
$costWatts    = 150.0;       // Cost for simulated download/export (Debit)
$rewardAmount = 1;           // Generic reward unit to add to the resource

// --- Helper Functions ---
function sendError($message, $status_code = 500) {
    http_response_code($status_code);
    header('Content-Type: application/json');
    echo json_encode(['status' => 'error', 'message' => $message]);
    exit();
}

// --- Initialize log file if missing ---
if (!file_exists($log_file)) {
    $initial_log = [[
        'capsule_mb'   => 0, 'cache_mb' => 0, 'real_kwh' => 0,
        'bandwidth'    => 0, 'torrent_mb' => 0, 'watts_dollar' => 150.00,
        'usd_value'    => 100.00,
        'profit_usd'   => 0.00,
        'timestamp'    => time()
    ]];
    file_put_contents($log_file, json_encode($initial_log, JSON_PRETTY_PRINT));
}

// --- File Locking ---
$fp = fopen($log_file, 'c+');
if (!$fp) sendError("Could not open log file for locking.");
if (!flock($fp, LOCK_EX | LOCK_NB)) {
    fclose($fp);
    sendError("Another transaction is in progress. Try again.", 503);
}

// --- Load current balance ---
$current_log = [];
$decoded_log = [];
$log_content = stream_get_contents($fp, -1, 0);

if ($log_content) {
    $decoded_log = json_decode($log_content, true);
    if (json_last_error() === JSON_ERROR_NONE && is_array($decoded_log) && !empty($decoded_log)) {
        $last_balance = end($decoded_log);
        if (is_array($last_balance)) $current_log = $last_balance;
    }
}
if (empty($current_log) || !isset($current_log['watts_dollar'])) {
    $current_log = [
        'capsule_mb'   => 0, 'cache_mb' => 0, 'real_kwh' => 0,
        'bandwidth'    => 0, 'torrent_mb' => 0, 'watts_dollar' => 150.00,
        'usd_value'    => 100.00,
        'profit_usd'   => 0.00,
        'timestamp'    => time()
    ];
}

// --- Determine file type ---
$fileType = $_POST['fileType'] ?? 'bin';
$fileNameBase = !empty($_POST['fileName'])
    ? preg_replace('/[^a-zA-Z0-9_\-]/', '', $_POST['fileName'])
    : 'rewards_' . $walletId;

$initialWatts = (float)($current_log['watts_dollar'] ?? 0);
if ($initialWatts < $costWatts) {
    flock($fp, LOCK_UN);
    fclose($fp);
    sendError("Insufficient Watts Dollar balance to cover the $costWatts transaction.", 402);
}

// --- Map fileType to resource key ---
$resourceKeyMap = [
    'bin'        => ['key' => 'capsule_mb',   'units' => 'BIN'],
    'json'       => ['key' => 'cache_mb',     'units' => 'JSON'],
    'json.bin'   => ['key' => 'torrent_mb',   'units' => 'JSON_BIN'],
    'watts_json' => ['key' => 'watts_dollar', 'units' => 'WATTS_JSON'],
    'kwh'        => ['key' => 'real_kwh',     'units' => 'KWH'],
    'capsule'    => ['key' => 'capsule_mb',   'units' => 'CAPSULE_MB'],
    'torrent'    => ['key' => 'torrent_mb',   'units' => 'TORRENT_MB'],
    'cache'      => ['key' => 'cache_mb',     'units' => 'CACHE_MB'],
    'bandwidth'  => ['key' => 'bandwidth',    'units' => 'BANDWIDTH_MBPS'],
];

$transaction = $resourceKeyMap[$fileType] ?? ['key' => null, 'units' => 'UNIT'];
$resourceKey = $transaction['key'];

// --- Debit Watts, credit resource ---
$newWatts = $initialWatts - $costWatts;
$new_entry = $current_log;
$new_entry['watts_dollar'] = $newWatts;
if ($resourceKey) {
    $new_entry[$resourceKey] = (float)($current_log[$resourceKey] ?? 0) + $rewardAmount;
}
$new_entry['timestamp'] = time();
$new_entry['action'] = "download_reward_debit_watts_and_credit_" . ($resourceKey ?: 'NONE');

// --- Append log ---
if (!is_array($decoded_log)) $decoded_log = [];
$decoded_log[] = $new_entry;
$json_output_log = json_encode($decoded_log, JSON_PRETTY_PRINT);
ftruncate($fp, 0);
rewind($fp);
fwrite($fp, $json_output_log);
flock($fp, LOCK_UN);
fclose($fp);

// --- Build export data ---
$downloadContent = [
    "wallet_id"        => $walletId,
    "resource"         => $resourceKey ?: 'n/a',
    "amount"           => $rewardAmount,
    "units"            => $transaction['units'],
    "timestamp"        => $new_entry['timestamp'],
    "block_header"     => "MM_BLOCK_HEADER_2025_SMALL",
    "overlay_constants"=> ["TE2" => "8.88e+17", "E2L" => "2.54e+34"]
];

// --- Output file ---
$output = json_encode($downloadContent, JSON_PRETTY_PRINT);
$mime   = 'application/json';
$ext    = '.' . $fileType;
$fileName = $fileNameBase . '_' . $fileType;

if ($fileType === 'torrent') {
    $mime = 'application/x-bittorrent';
} elseif ($fileType === 'bin' || $fileType === 'json.bin') {
    $mime = 'application/octet-stream';
} elseif ($fileType === 'kwh') {
    $output = json_encode(array_merge($downloadContent, ["plant_name" => "Manierism Electrism"]), JSON_PRETTY_PRINT);
}

header("Content-Type: $mime");
header("Content-Disposition: attachment; filename=\"$fileName$ext\"");
echo $output;
exit;
?>
