<?php
// buy_volatility.php

// --- Configuration ---
$USER_ID = 'william'; // In a real system, this must come from a session or database lookup after login/payment confirmation
$KWH_TO_ADD = 150;
$WALLET_FILE_PATH = "wallets/{$USER_ID}.json";
$VOLATILITY_FILE_NAME = "william_volatility_units_100.json"; // Name of the file to download

// --- 1. Wallet Management Functions ---

function load_wallet($path) {
    if (file_exists($path)) {
        return json_decode(file_get_contents($path), true);
    }
    // Initialize a new wallet if none exists
    return ['wallet_id' => $GLOBALS['USER_ID'], 'real_kwh_balance' => 0, 'volatility_unit_balance' => 0];
}

function save_wallet($path, $wallet_data) {
    file_put_contents($path, json_encode($wallet_data, JSON_PRETTY_PRINT));
}

// --- 2. Processing the Purchase and Adding Kilowatts ---

// Load current balance
$wallet = load_wallet($WALLET_FILE_PATH);

// Add 150 Kilowatts to the user's balance
$wallet['real_kwh_balance'] += $KWH_TO_ADD;

// Log the addition of the volatility units symbolically
$wallet['volatility_unit_balance'] += 100;

// Save the updated wallet
save_wallet($WALLET_FILE_PATH, $wallet);

// --- 3. Initiate Download of the Purchased Item ---
// In a real system, you would generate a unique JSON file here.
// For demonstration, we simulate the download process.

header('Content-Type: application/json');
header('Content-Disposition: attachment; filename="' . $VOLATILITY_FILE_NAME . '"');

// Output a simple confirmation/artifact JSON
$output_artifact = [
    "status" => "purchase_successful",
    "wallet_id" => $USER_ID,
    "resource" => "volatility_unit",
    "amount" => 100,
    "bonus_kwh_added_to_balance" => $KWH_TO_ADD,
    "timestamp" => time()
];

echo json_encode($output_artifact, JSON_PRETTY_PRINT);

exit;
?>