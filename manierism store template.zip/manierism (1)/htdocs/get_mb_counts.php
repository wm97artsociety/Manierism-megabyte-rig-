<?php
// Set the content type to JSON
header('Content-Type: application/json');

// Megabyte Market count files
$FAUCET_COUNT_FILE = 'mb_faucet_count.txt';
$PAID_COUNT_FILE   = 'mb_paid_count.txt';

function read_count($file_path) {
    return file_exists($file_path) ? (int)trim(file_get_contents($file_path)) : 0;
}

echo json_encode([
    'faucet_count' => read_count($FAUCET_COUNT_FILE),
    'paid_count'   => read_count($PAID_COUNT_FILE)
]);
?>