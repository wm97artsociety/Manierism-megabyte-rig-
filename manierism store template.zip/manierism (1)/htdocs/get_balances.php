<?php
// get_balances.php — returns balances for wallet_id
declare(strict_types=1);
require_once __DIR__ . '/db.php';

header('Content-Type: application/json; charset=UTF-8');

// --- Helper for errors ---
function sendError(string $message, int $status_code = 404): void {
    http_response_code($status_code);
    echo json_encode(["status" => "error", "message" => $message]);
    exit();
}

$wallet_id = isset($_GET['wallet_id']) ? trim($_GET['wallet_id']) : 'trust';

try {
    $stmt = $pdo->prepare("
        SELECT wallet_id,
               capsule_mb,
               cache_mb,
               real_kwh,
               bandwidth,
               torrent_mb,
               watts_dollar,
               usd_value,
               profit_usd,
               liquidity_usd
        FROM balances
        WHERE wallet_id = ?
        LIMIT 1
    ");
    $stmt->execute([$wallet_id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        sendError("Wallet '{$wallet_id}' not found", 404);
    }

    echo json_encode([
        "status" => "ok",
        "data"   => $row
    ], JSON_PRETTY_PRINT);

} catch (PDOException $e) {
    sendError("Database error: " . $e->getMessage(), 500);
} catch (Throwable $e) {
    sendError("Unexpected error: " . $e->getMessage(), 500);
}
