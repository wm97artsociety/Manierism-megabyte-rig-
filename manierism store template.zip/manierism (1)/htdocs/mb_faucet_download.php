<?php
date_default_timezone_set('UTC');

// Configuration for Megabytes Faucet
$AMOUNT_PER_DOWNLOAD_MBS = 100.0; 
$FAUCET_COUNT_FILE = __DIR__ . '/mb_faucet_count.txt'; // Resource-specific counter file
$HOURLY_LIMIT_SECONDS = 3600; // 1 hour limit

// --- 1. Simple IP-based rate limiting (1 hour) ---
$ip = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
$log_dir = __DIR__ . '/mb_faucet_logs';
$ip_log_file = $log_dir . '/' . md5($ip) . '.log';

if (!is_dir($log_dir)) {
    mkdir($log_dir, 0775, true);
}

if (file_exists($ip_log_file) && (time() - filemtime($ip_log_file)) < $HOURLY_LIMIT_SECONDS) {
    http_response_code(429);
    die("IP restricted. Please wait 1 hour for the next free download.");
}
file_put_contents($ip_log_file, gmdate("c"));

// --- 2. Update Faucet Count ---
$currentCount = 0;
if (file_exists($FAUCET_COUNT_FILE)) {
    $currentCount = (int)file_get_contents($FAUCET_COUNT_FILE);
}
file_put_contents($FAUCET_COUNT_FILE, $currentCount + 1);

// --- 3. Generate Receipt JSON and Send Download ---
$receiptId = bin2hex(random_bytes(8));
$capsule = [
    "wallet_id" => "trust", "rig_id" => "trust",
    "node_id" => "c590fb1b-44c5-4bd9-b6d1-e2ce14fd1df3",
    "resource" => "megabytes", "amount" => $AMOUNT_PER_DOWNLOAD_MBS,
    "timestamp" => microtime(true),
    "overlay_constants" => ["TEЛ² constant" => "8.88 x 10¹⁷", "E²Л constant" => "2.54 x 10³⁴"],
    "receipt_meta" => ["receipt_id" => $receiptId, "issued_at" => gmdate("c"), "source" => "Megabyte Faucet - Artifact"]
];

header('Content-Type: application/json');
header('Content-Disposition: attachment; filename="faucet_100mbs_' . $receiptId . '.json"');
echo json_encode($capsule, JSON_PRETTY_PRINT);
exit;
?>