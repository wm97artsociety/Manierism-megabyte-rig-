<?php
// index.php — storefront page
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Manierism Megabytes - Digital Battery Kits</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body { font-family: 'Inter', sans-serif; background:#f4f4f4; margin:0; }
    .top-bar { background:#333; color:white; padding:15px 20px; display:flex; justify-content:flex-start; gap:40px; align-items:center; }
    .support-btn { background:#635bff; color:white; padding:8px 16px; border-radius:6px; text-decoration:none; }
    .page-container { max-width:1200px; margin:30px auto; padding:0 20px; }
    .product-shelf { display:flex; flex-wrap:wrap; gap:30px; justify-content:center; }
    .product-box { background:white; border:1px solid #ddd; border-radius:10px; padding:20px; flex:1; min-width:300px; max-width:500px; box-shadow:0 4px 6px rgba(0,0,0,0.05); }
    .product-header { text-align:center; margin-bottom:20px; }
    .product-image-container { height:200px; display:flex; justify-content:center; align-items:center; overflow:hidden; margin-bottom:15px; }
    .product-image { max-width:100%; max-height:100%; border-radius:6px; object-fit:contain; }
    .product-title { font-size:1.5rem; font-weight:bold; margin:0; }
    .subtitle { color:#555; margin-top:5px; }
    .faucet-limit { font-size:0.9rem; color:#cc0000; margin-top:5px; }
    .product-actions { text-align:center; margin-bottom:20px; }
    .download-button, .purchase-button { display:block; width:100%; padding:12px; margin:10px 0; border:none; border-radius:6px; font-weight:bold; cursor:pointer; text-align:center; text-decoration:none; }
    .download-button { background:#2ecc71; color:white; }
    .purchase-button { background:#635bff; color:white; }
    .download-counter { font-size:1rem; color:#333; }
    .restriction-note { font-size:0.8rem; color:#888; margin-top:5px; }
    footer { background:#333; color:#ccc; text-align:center; padding:20px; margin-top:40px; }
    footer a { color:#00aced; text-decoration:none; font-weight:bold; }
    footer a:hover { text-decoration:underline; }
    .menu { display:flex; gap:20px; }
    .menu-link { color:white; text-decoration:none; font-weight:bold; transition:color 0.2s ease; }
    .menu-link:hover { color:#2ecc71; }
  </style>
</head>
<body>

<div class="top-bar">
  <div>
    <h1>🌎 Manierism Megabytes Marketplace</h1>
    <p>Digital Energy capsules</p>
  </div>
  <nav class="menu">
    <a href="index.php" class="menu-link">⚡ Electricity</a>
    <a href="watts.html" class="menu-link">💰 Watts Dollar Capsules</a>
    <a href="data.html" class="menu-link">💾 Data Market Center</a>
    <a href="stock.php" class="menu-link">📈 Stock Market</a>
  </nav>
  <a href="support.html" class="btn support-btn">📧 Support</a>
</div>

<div class="page-container">
  <div class="product-shelf">

    <!-- Free Faucet -->
    <div class="product-box" id="box-1kwh">
      <div class="product-header">
        <div class="product-image-container">
          <img src="electrism.jpg" alt="Electricism Banner" class="product-image">
        </div>
        <h3 class="product-title">1 Free Kilowatt Digital Battery Test Kit</h3>
        <p class="subtitle">1 Kilowatt Digital Battery File Download (Electro Faucet)</p>
        <p class="faucet-limit">**1 every 24 hours**</p>
      </div>
      <div class="product-actions">
        <button class="download-button" onclick="window.location.href='faucet_download.php'">FREE DOWNLOAD</button>
        <p class="download-counter">**Today's Faucet Claims: <span id="download-count-1kwh">Loading...</span>**</p>
        <p class="restriction-note">*IP restricted to one download every 24 hours.*</p>
      </div>
    </div>

    <!-- Paid Purchase -->
    <div class="product-box" id="box-100kwh">
      <div class="product-header">
        <div class="product-image-container">
          <img src="electrism.jpg" alt="Electricism Banner" class="product-image">
        </div>
        <h3 class="product-title">100 Kilowatt Digital Battery File Download</h3>
        <p class="subtitle">The Maximum Symbolic Discharge Capsule</p>
        <p class="faucet-limit">**Single Purchase**</p>
      </div>
      <div class="product-actions">
        <a href="https://donate.stripe.com/4gM9AUed1bWtgngaHG0ZW00" class="purchase-button" target="_blank" rel="noopener">
          Purchase 100 kWh File ($1.00)
        </a>
        <p class="download-counter">**Total Sales: <span id="download-count-100kwh">Loading...</span>**</p>
        <p class="restriction-note">*Redirects to download page after payment for downloads.*</p>
      </div>
    </div>

  </div>
</div>

<footer>
  <p>© 2025 Wm97 star powered. All rights reserved.</p>
  <p>Visit our sister store: 
    <a href="https://payhip.com/Manierismmegabytes" target="_blank" rel="noopener">
      Payhip.com/Manierismmegabytes
    </a>
  </p>
</footer>

<script>
  function updateDownloadCounts() {
    fetch('get_counts.php')
      .then(response => response.json())
      .then(data => {
        document.getElementById('download-count-1kwh').textContent = data.faucet_count;
        document.getElementById('download-count-100kwh').textContent = data.paid_count;
      })
      .catch(error => {
        console.error('Error fetching counts:', error);
        document.getElementById('download-count-1kwh').textContent = 'Error';
        document.getElementById('download-count-100kwh').textContent = 'Error';
      });
  }
  updateDownloadCounts();
</script>

</body>
</html>
