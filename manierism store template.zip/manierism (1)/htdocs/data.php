<?php
$file = __DIR__ . "/william_bandwidth_MBps_100000000000000000000000000000000000000000000000000000000000000000_json.json";

header('Content-Type: application/json');
header('Content-Disposition: attachment; filename="data_mbs.json"');
readfile($file);
exit;
?>
