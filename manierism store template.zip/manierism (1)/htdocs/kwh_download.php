<?php
date_default_timezone_set('UTC');

// Configuration for Kilowatt-hour Purchase (Original values restored)
$AMOUNT_PER_DOWNLOAD_KWH = 100.0; 
$BALANCE_FILE = __DIR__ . '/balance.json';
$LEDGER_FILE  = __DIR__ . '/ledger/kwh_events.log'; // Resource-specific ledger
$RECEIPTS_DIR = __DIR__ . '/kwh_receipts'; // Resource-specific receipts
$PAID_COUNT_FILE = __DIR__ . '/kwh_paid_count.txt'; // Resource-specific counter

// Setup directories
if (!is_dir($RECEIPTS_DIR)) mkdir($RECEIPTS_DIR, 0775, true);
if (!is_dir(dirname($LEDGER_FILE))) mkdir(dirname($LEDGER_FILE), 0775, true);

// --- 1. Lock, Read, and Validate Balance ---
$fp = fopen($BALANCE_FILE, 'c+');
if (!$fp || !flock($fp, LOCK_EX)) { http_response_code(500); exit("Balance file error/lock failed"); }

$balance = json_decode(stream_get_contents($fp), true) ?? [];
// IMPORTANT: Checks the 'remaining_kwh' key
$remaining_amount = $balance['remaining_kwh'] ?? 0;

if ($remaining_amount < $AMOUNT_PER_DOWNLOAD_KWH) {
  flock($fp, LOCK_UN); fclose($fp);
  http_response_code(409);
  exit("Insufficient balance for 100 kWh. Remaining: " . $remaining_amount); 
}

// --- 2. Perform Deduction and Update Balance ---
$balance['remaining_kwh'] -= $AMOUNT_PER_DOWNLOAD_KWH;
$balance['last_updated'] = gmdate("c");

ftruncate($fp, 0); rewind($fp);
fwrite($fp, json_encode($balance, JSON_PRETTY_PRINT)); 
fflush($fp); flock($fp, LOCK_UN); fclose($fp);

// --- 3. Update Paid Count ---
$currentCount = 0;
if (file_exists($PAID_COUNT_FILE)) {
    $currentCount = (int)file_get_contents($PAID_COUNT_FILE);
}
file_put_contents($PAID_COUNT_FILE, $currentCount + 1);

// --- 4. Generate Receipt & Log Ledger Entry ---
$receiptId = bin2hex(random_bytes(8));
$capsule = [
  "resource" => "real_kwh", "amount" => $AMOUNT_PER_DOWNLOAD_KWH,
  // ... (other metadata) ...
  "receipt_meta" => ["receipt_id" => $receiptId, "issued_at" => gmdate("c"), "source" => "Symbolic Kilowatt Purchase"]
];
file_put_contents($RECEIPTS_DIR . "/receipt_" . $receiptId . ".json", json_encode($capsule, JSON_PRETTY_PRINT));

$ledgerEntry = [
  "type" => "symbolic_kwh_download", "amount" => $AMOUNT_PER_DOWNLOAD_KWH,
  "remaining_balance" => $balance['remaining_kwh'], "receipt_id" => $receiptId,
  "ip" => $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN'
];
file_put_contents($LEDGER_FILE, json_encode($ledgerEntry) . "\n", FILE_APPEND | LOCK_EX);

// --- 5. Send Download ---
header('Content-Type: application/json');
header('Content-Disposition: attachment; filename="paid_100kwh_' . $receiptId . '.json"'); 
echo json_encode($capsule, JSON_PRETTY_PRINT);
exit;
?>