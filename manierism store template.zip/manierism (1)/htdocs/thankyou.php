<?php
// thankyou.php — credit Watts Dollar then redirect to thank.html
declare(strict_types=1);
require __DIR__ . '/db.php';
session_start();

header('Content-Type: text/html; charset=UTF-8');

$walletId = $_SESSION['wallet_id'] ?? 'trust';

try {
    // Get last order
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE wallet_id = ? ORDER BY id DESC LIMIT 1");
    $stmt->execute([$walletId]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($order) {
        // Credit Watts Dollar (17 per trade)
        $wattsReward = (float)$order['trades'] * 17.00;

        // Ensure wallet exists
        $check = $pdo->prepare("SELECT wallet_id FROM balances WHERE wallet_id = ?");
        $check->execute([$walletId]);
        $bal = $check->fetch(PDO::FETCH_ASSOC);

        if ($bal) {
            $update = $pdo->prepare("
                UPDATE balances 
                SET watts_dollar = COALESCE(watts_dollar,0) + :watts,
                    updated_at   = CURRENT_TIMESTAMP
                WHERE wallet_id = :wid
            ");
            $update->execute([':watts' => $wattsReward, ':wid' => $walletId]);
        } else {
            $insert = $pdo->prepare("
                INSERT INTO balances (wallet_id, watts_dollar, usd_value, profit_usd, liquidity_usd, updated_at)
                VALUES (:wid, :watts, 0, 0, 0, CURRENT_TIMESTAMP)
            ");
            $insert->execute([':wid' => $walletId, ':watts' => $wattsReward]);
        }

        // Redirect to thank.html with product + amount
        $product = "index";
        $amount  = (int)$order['trades'];
        header("Location: thank.html?product={$product}&amount={$amount}");
        exit();
    } else {
        echo "<h3>No order found for wallet: " . htmlspecialchars($walletId, ENT_QUOTES, 'UTF-8') . "</h3>";
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo "<h3>Database error: " . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . "</h3>";
} catch (Throwable $e) {
    http_response_code(500);
    echo "<h3>Unexpected error: " . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . "</h3>";
}
