<?php
// process_payment.php — PROCESSES BUYER PAYMENT VIA STRIPE CONNECT
// Charges buyer on behalf of seller, splits fee, updates escrow/wallets

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=UTF-8');

require_once 'vendor/autoload.php'; // Stripe PHP library

\Stripe\Stripe::setApiKey('sk_live_xxx'); // replace with your real secret key

$wallets_dir = __DIR__ . '/wallets';
$escrow_dir  = __DIR__ . '/escrow';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'POST only']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$listing_id    = $data['listing_id']    ?? null;
$buyer_wallet  = $data['buyer_wallet']  ?? null;
$payment_method= $data['payment_method']?? null;
$donation_fee  = (float)($data['donation_fee'] ?? 0.00); // enforce penny minimum

if (!$listing_id || !$buyer_wallet || !$payment_method) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid data']);
    exit;
}
if ($donation_fee < 0.01) {
    echo json_encode(['status' => 'error', 'message' => 'Minimum $0.01 donation required']);
    exit;
}

// Load escrow listing
$escrow_file = $escrow_dir . '/' . $listing_id . '.json';
if (!file_exists($escrow_file)) {
    echo json_encode(['status' => 'error', 'message' => 'Listing not found']);
    exit;
}

$listing       = json_decode(file_get_contents($escrow_file), true);
$seller_wallet = $listing['seller_id'];
$seller_account= $listing['seller_account'] ?? null;
$kwh           = $listing['kwh'];
$price_usd     = $listing['price_usd'];
$platform_fee  = $price_usd * 0.10; // 10% platform fee

if (!$seller_account) {
    echo json_encode(['status' => 'error', 'message' => 'Seller not onboarded']);
    exit;
}

// Create PaymentIntent on behalf of seller (Connect)
try {
    $payment_intent = \Stripe\PaymentIntent::create([
        'amount'               => (int)($price_usd * 100), // cents
        'currency'             => 'usd',
        'payment_method'       => $payment_method,
        'confirmation_method'  => 'manual',
        'confirm'              => true,
        'application_fee_amount'=> (int)($platform_fee * 100),
        'transfer_data'        => ['destination' => $seller_account],
        'metadata'             => [
            'listing_id'   => $listing_id,
            'buyer_wallet' => $buyer_wallet,
            'seller_wallet'=> $seller_wallet,
        ],
    ]);

    if ($payment_intent->status === 'succeeded') {
        // Update escrow
        $listing['status']            = 'sold';
        $listing['payment_intent_id'] = $payment_intent->id;
        $listing['sold_at']           = time();
        file_put_contents($escrow_file, json_encode($listing, JSON_PRETTY_PRINT));

        // Add kWh to buyer wallet
        $buyer_file = $wallets_dir . '/' . md5($buyer_wallet) . '.json';
        if (file_exists($buyer_file)) {
            $buyer = json_decode(file_get_contents($buyer_file), true);
            $buyer['real_kwh'] = ($buyer['real_kwh'] ?? 0) + $kwh;
            file_put_contents($buyer_file, json_encode($buyer, JSON_PRETTY_PRINT));
        }

        // Add USD and Watts$ to seller wallet
        $seller_file = $wallets_dir . '/' . md5($seller_wallet) . '.json';
        if (file_exists($seller_file)) {
            $seller = json_decode(file_get_contents($seller_file), true);
            $seller['usd_value'] = ($seller['usd_value'] ?? 0) + ($price_usd - $platform_fee);
            // Reward based on donation fee, not price
            $watts_reward = floor($donation_fee / 0.50) * 17;
            $seller['watts_dollar'] = ($seller['watts_dollar'] ?? 0) + $watts_reward;
            file_put_contents($seller_file, json_encode($seller, JSON_PRETTY_PRINT));
        }

        echo json_encode([
            'status'       => 'ok',
            'payment_id'   => $payment_intent->id,
            'watts_reward' => $watts_reward,
            'message'      => "Payment complete! {$kwh} kWh transferred to buyer.",
            'receipt_url'  => 'https://manierismegabyte.infinityfreeapp.com/thank.html?product=buy&amount=' . $kwh,
            'donation_url' => 'https://donate.stripe.com/14A28s2ujaSpb2W1760ZW05'
        ]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Payment requires action']);
    }
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>