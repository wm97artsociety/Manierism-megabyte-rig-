<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$claimed_file = __DIR__ . '/claimed_ips.json';

// --- Ensure file exists ---
if (!file_exists($claimed_file)) {
    file_put_contents($claimed_file, json_encode([], JSON_PRETTY_PRINT));
}

// --- Load claimed IPs ---
$claimed = json_decode(file_get_contents($claimed_file), true);
if (!is_array($claimed)) {
    $claimed = [];
}

// --- Optional: allow clearing via ?reset=1 ---
if (isset($_GET['reset']) && $_GET['reset'] == '1') {
    $claimed = [];
    file_put_contents($claimed_file, json_encode($claimed, JSON_PRETTY_PRINT));
    echo json_encode([
        "status" => "ok",
        "message" => "Claimed IPs reset",
        "claimed" => $claimed
    ]);
    exit;
}

// --- Respond with current claimed IPs ---
echo json_encode([
    "status"  => "ok",
    "claimed" => $claimed
], JSON_PRETTY_PRINT);
exit;
