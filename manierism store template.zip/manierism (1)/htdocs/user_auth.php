<?php
header('Content-Type: application/json');
include 'config.php'; // For $pdo

$action = $_POST['action'] ?? ''; // 'login', 'register', or 'get_user'
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

if ($action === 'login' && $username && $password) {
    try {
        $stmt = $pdo->prepare("SELECT id, password FROM users WHERE username = ?"); // Assume hashed pwds
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            echo json_encode(['status' => 'success', 'user_id' => $user['id']]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Invalid credentials']);
        }
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => 'Auth failed: ' . $e->getMessage()]);
    }
    exit;
}

if ($action === 'register' && $username && $password) {
    try {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        $stmt->execute([$username, $hashed]);
        $_SESSION['user_id'] = $pdo->lastInsertId();
        // Init per-user balances
        $user_balances = $default_balances ?? ['real_kwh' => 0, 'watts_dollar' => 0 /* etc from swap.php */];
        file_put_contents(__DIR__ . "/balances_{$_SESSION['user_id']}.json", json_encode($user_balances));
        echo json_encode(['status' => 'success', 'user_id' => $_SESSION['user_id']]);
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => 'Registration failed: ' . $e->getMessage()]);
    }
    exit;
}

if ($action === 'get_user') {
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
        $balances_file = __DIR__ . "/balances_$user_id.json";
        $balances = file_exists($balances_file) ? json_decode(file_get_contents($balances_file), true) : [];
        echo json_encode(['status' => 'success', 'user_id' => $user_id, 'balances' => $balances]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
    }
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'Invalid action']);
?>