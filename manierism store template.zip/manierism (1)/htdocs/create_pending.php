<?php
// create_pending.php - Create pending payment entry for OKX monitoring
header('Content-Type: application/json; charset=utf-8');

$pending_file = __DIR__ . '/pending_payments.json';
$wallets_dir = __DIR__ . '/wallets';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'POST only']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$wallet_id = $data['wallet_id'] ?? null;
$action = $data['action'] ?? null;
$amount_usd = floatval($data['amount_usd'] ?? 0);
$ccy = $data['ccy'] ?? 'USDT';
$timestamp = intval($data['timestamp'] ?? 0);

if (!$wallet_id || !$action || $amount_usd <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid data']);
    exit;
}

// Load pendings
$pendings = file_exists($pending_file) ? json_decode(file_get_contents($pending_file), true) : [];

// Generate unique ID
$pending_id = uniqid('PEND-');

// Add new pending
$pendings[] = [
    'pending_id' => $pending_id,
    'wallet_id' => $wallet_id,
    'action' => $action,
    'amount_usd' => $amount_usd,
    'ccy' => $ccy,
    'timestamp' => $timestamp,
    'status' => 'pending',
    'created_at' => time()
];

// Save
file_put_contents($pending_file, json_encode($pendings, JSON_PRETTY_PRINT), LOCK_EX);

echo json_encode([
    'status' => 'ok',
    'pending_id' => $pending_id,
    'message' => 'Pending payment created. Monitor for deposit.'
]);
?>