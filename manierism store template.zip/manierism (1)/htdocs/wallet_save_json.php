<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=UTF-8');

$file = __DIR__ . '/balances.json';
$raw = file_get_contents('php://input');
$data = json_decode($raw, true);

if (!is_array($data)) {
  echo json_encode(["status"=>"error","message"=>"Invalid JSON body"]); exit;
}

$defaults = [
  "capsule_mb"=>125,"cache_mb"=>250,"real_kwh"=>150.000000,"bandwidth"=>100,
  "torrent_mb"=>50,"watts_dollar"=>7.50,"usd_value"=>0,"kilowatt_liquidity_usd"=>100000
];

// Merge with defaults and normalize
$merged = array_merge($defaults, array_intersect_key($data, $defaults));
foreach ($merged as $k=>$v) { $merged[$k] = is_numeric($v)?(float)$v:0.0; }

file_put_contents($file, json_encode($merged, JSON_PRETTY_PRINT));
echo json_encode(["status"=>"ok","balances"=>$merged], JSON_PRETTY_PRINT);
