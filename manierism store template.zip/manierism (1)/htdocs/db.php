<?php
// db.php — YOUR ORIGINAL (Keep this!)
declare(strict_types=1);

// --- Database credentials ---
$host     = "";
$dbname   = "";
$username = "";
$password = "";

// --- DSN string ---
$dsn = "mysql:host={$host};dbname={$dbname};charset=utf8mb4";

try {
    // Create PDO instance
    $pdo = new PDO($dsn, $username, $password, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false
    ]);
} catch (PDOException $e) {
    // Fail gracefully with JSON error
    http_response_code(500);
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode([
        "status"  => "error",
        "message" => "Database connection failed"
    ]);
    exit();
}
?>