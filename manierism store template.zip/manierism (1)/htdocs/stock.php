<?php
// PHP Script to handle the creation (minting) of a new stock/token.
// This script requires a writable file named 'stocks.json' in the same directory.
// It will fail if placed on a server without PHP configured or if stocks.json is not accessible.

header('Content-Type: application/json');

$stocks_file = 'stocks.json';
$method = $_SERVER['REQUEST_METHOD'];

// --- Function to handle errors and exit gracefully ---
function sendError($message, $status_code = 400) {
    http_response_code($status_code);
    echo json_encode(['status' => 'error', 'message' => $message]);
    exit();
}

// --- Ensure this is a POST request ---
if ($method !== 'POST') {
    sendError("Invalid request method. Only POST is allowed.", 405);
}

// --- 1. Get and validate input data ---
$tokenSymbol = filter_input(INPUT_POST, 'tokenSymbol', FILTER_SANITIZE_STRING);
$initialSupply = filter_input(INPUT_POST, 'initialSupply', FILTER_VALIDATE_FLOAT);
$baseValue = filter_input(INPUT_POST, 'baseValue', FILTER_VALIDATE_FLOAT);

if (!$tokenSymbol || !$initialSupply || !$baseValue || $initialSupply <= 0 || $baseValue <= 0) {
    sendError("Missing or invalid token parameters. All fields must be positive values.");
}

$tokenSymbol = strtoupper(substr($tokenSymbol, 0, 5)); // Enforce max 5 chars
$totalCollateral = round($initialSupply * $baseValue, 2);

// --- 2. Load existing stock data (or initialize if non-existent) ---
$stocks = [];
if (file_exists($stocks_file)) {
    $current_data = file_get_contents($stocks_file);
    if ($current_data) {
        $stocks = json_decode($current_data, true);
        if ($stocks === null) {
            $stocks = []; // Reset if JSON file is corrupted
        }
    }
}

// --- 3. Check for duplicates ---
foreach ($stocks as $stock) {
    if ($stock['tokenSymbol'] === $tokenSymbol) {
        sendError("Token symbol '$tokenSymbol' already exists in the market.");
    }
}

// --- 4. Create new token object ---
$newToken = [
    'tokenSymbol' => $tokenSymbol,
    'initialSupply' => $initialSupply,
    'baseValue' => $baseValue,
    'collateralWattsDollar' => $totalCollateral,
    'status' => 'Active',
    'created_at' => date('Y-m-d H:i:s')
];

$stocks[] = $newToken;

// --- 5. Save the updated data back to the file ---
$success = file_put_contents($stocks_file, json_encode($stocks, JSON_PRETTY_PRINT));

if ($success === false) {
    sendError("Failed to save new stock data to file. Check write permissions on 'stocks.json'.");
}

// --- 6. Send success response ---
http_response_code(201);
echo json_encode([
    'status' => 'success',
    'message' => "Token $tokenSymbol minted successfully.",
    'data' => $newToken
]);

?>