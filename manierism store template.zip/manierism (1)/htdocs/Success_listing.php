<?php
session_start();
if (!isset($_SESSION['pending_order'])) { header("Location: stock.html"); exit; }

$order = $_SESSION['pending_order'];
unset($_SESSION['pending_order']);

$orders = json_decode(file_get_contents('data/orders.json'), true) ?? [];
$orders[] = $order;
file_put_contents('data/orders.json', json_encode($orders, JSON_PRETTY_PRINT));

$receipt_id = 'LIST-' . strtoupper(dechex($order['time'] % 0xFFFFFF));
$receipt = [
  "receipt_id"       => $receipt_id,
  "exchange"         => "Mom & Pop Watts Exchange",
  "action"           => "kWh Listed (ASK)",
  "status"           => "LIVE ON MARKET",
  "timestamp_utc"    => gmdate("Y-m-d H:i:s", $order['time']) . " UTC",
  "wallet_id"        => $order['wallet'],
  "kwh_listed"       => $order['kwh'],
  "price_watts"      => $order['price'],
  "listing_fee_usd"  => 0.01,
  "message"          => "Your {$order['kwh']} kWh is live for sale!"
];

header('Content-Type: application/json');
header('Content-Disposition: attachment; filename="WattsReceipt_'.$receipt_id.'.json"');
echo json_encode($receipt, JSON_PRETTY_PRINT);
exit;