<?php
// download_kwh_1.php - Free 1 kWh with 30-minute IP cooldown

// --- IP COOLDOWN LOGIC SETUP ---
$COOLDOWN_SECONDS = 30 * 60; // 30 minutes restriction
$STORAGE_FILE = 'faucet_logs.json'; // Shared log file for faucet claims

/**
 * Safely determines the client's public IP address, handling common proxy headers.
 * Filters out private and reserved IP ranges.
 */
function getIP() {
    $keys = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_CLIENT_IP', 'REMOTE_ADDR'];
    foreach ($keys as $key) {
        if (!empty($_SERVER[$key])) {
            // Take the first IP if it's a comma-separated list
            $ip = trim(explode(',', $_SERVER[$key])[0]);
            // Validate IP to exclude private/reserved ranges
            if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                return $ip;
            }
        }
    }
    return $_SERVER['REMOTE_ADDR'] ?? 'unknown';
}

$ip = getIP();
$now = time();

// Load logs safely
$logs = [];
if (file_exists($STORAGE_FILE)) {
    $content = file_get_contents($STORAGE_FILE);
    // Use @ to suppress JSON decoding errors for malformed files
    $logs = @json_decode($content, true) ?: []; 
}

// Clean old entries (older than 24 hours = 86400 seconds)
$logs = array_filter($logs, fn($e) => ($now - $e['time']) < 86400);

// --- COOLDOWN CHECK ---
if (isset($logs[$ip]) && ($now - $logs[$ip]['time']) < $COOLDOWN_SECONDS) {
    $wait = ceil(($logs[$ip]['time'] + $COOLDOWN_SECONDS - $now) / 60);
    http_response_code(429); // Too Many Requests
    header('Content-Type: application/json');
    echo json_encode([
        "error" => "Too soon!",
        "message" => "Wait $wait more minute(s) before claiming again. Cooldown: 30 minutes.",
        "retry_in_minutes" => $wait
    ], JSON_PRETTY_PRINT);
    exit;
}

// --- FILE GENERATION (Only runs if cooldown check passes) ---
$node_id = uniqid("free-1kwh-");

$data = [
    "wallet_id" => "manierism_free",
    "rig_id"    => "electrism_faucet",
    "node_id"   => $node_id,
    "resource"  => "real_kwh",
    "amount"    => 1.0,
    "timestamp" => microtime(true),
    "overlay_constants" => [
        "TEЛ²" => "8.88e+17",
        "E²Л" => "2.54e+34",
        "block_header" => "MMBLOCKHEADER2025"
    ],
    "capsule_settlement" => [
        "plant_name" => "Manierism Electrism",
        "currency"   => "USD",
        "usd_value"  => 0.63,
        "note"       => "Free 1 kWh — gift from William (IP Cooldown Enforced)"
    ],
    "receipt_meta" => [
        "type"    => "free_1kwh",
        "source"  => "Manierism Kilowatts Faucet",
        "message" => "The grid remembers you. Download logged."
    ]
];

// --- UPDATE LOG (After successful claim) ---
// Log the new download time for the user's IP
$logs[$ip] = ['time' => $now, 'node' => $node_id];
file_put_contents($STORAGE_FILE, json_encode($logs, JSON_PRETTY_PRINT));


// --- DELIVER FILE ---
header('Content-Type: application/json');
// Use the generated node_id in the filename for uniqueness and tracking
header("Content-Disposition: attachment; filename=\"Manierism_1kWh_Free_{$node_id}.json\"");
header('Cache-Control: no-store'); // Ensure the file is not cached by the browser

echo json_encode($data, JSON_PRETTY_PRINT);
?>