<?php
// download_100kwh.php - Delivered after $1 Stripe payment

$node_id = 'paid100-' . bin2hex(random_bytes(4));

$data = [
    "wallet_id" => "manierism_premium",
    "rig_id" => "electrism_max",
    "node_id" => $node_id,
    "resource" => "symbolic_kilowatts",
    "amount_kwh" => 100.0,
    "timestamp" => microtime(true),
    "block_header" => "MMBLOCKHEADER2025",
    "purchase_confirmed" => true,
    "usd_paid" => 1.00,
    "message" => "Thank you for supporting the grid. 100 kWh now yours forever.",
    "rights" => "Full resale • remix • amplification • gifting allowed"
];

header('Content-Type: application/json');
header('Content-Disposition: attachment; filename="Manierism_100kWh_Premium_' . $node_id . '.json"');
echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
?>