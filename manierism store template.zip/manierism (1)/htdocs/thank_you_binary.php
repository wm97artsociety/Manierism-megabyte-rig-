<?php
// thank_you_binary.php
header('Content-Type: application/json');
header('Content-Disposition: attachment; filename="binary_capsule_500k.json"');

// Capture form inputs
$name = $_POST['customer_name'] ?? 'Anonymous';
$note = $_POST['thank_you_note'] ?? '';
$plan = $_POST['kilowatt_plan'] ?? '';

// Calculate kilowatt amount: $500,000 / $0.15 per kWh
$rate = 0.15;
$amount_kwh = 500000 / $rate;

$data = [
    "wallet_id" => "binary_capsule",
    "rig_id" => "binary_capsule",
    "node_id" => uniqid("binary-"),
    "resource" => "real_kwh",
    "amount" => $amount_kwh,
    "timestamp" => microtime(true),
    "overlay_constants" => [
        "TEЛ²" => "8.88e+17",
        "E²Л" => "2.54e+34",
        "block_header" => "MM_BLOCK_HEADER_2025"
    ],
    "capsule_settlement" => [
        "plant_name" => "Manierism Electrism",
        "currency" => "USD",
        "usd_value" => 500000,
        "rate_per_kwh" => $rate
    ],
    "user_details" => [
        "name" => $name,
        "thank_you_note" => $note,
        "kilowatt_plan" => $plan
    ]
];

echo json_encode($data, JSON_PRETTY_PRINT);
?>
