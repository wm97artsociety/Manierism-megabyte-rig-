<?php
header('Content-Type: application/json');

$file = __DIR__ . '/balances.json';
$log  = __DIR__ . '/trades_log.json';

// Default balances if file missing
$default = [
    "capsule_mb"   => 0.0,
    "cache_mb"     => 0.0,
    "real_kwh"     => 0.0,
    "bandwidth"    => 0.0,
    "torrent_mb"   => 0.0,
    "watts_dollar" => 0.0,
    "usd_value"    => 0.0,
    "profit_usd"   => 0.0,
    "feature_unlocked" => false, // New: Tracks if $10 profit unlock for USD swap
    "last_updated" => gmdate("c")
];
if (!file_exists($file)) {
    file_put_contents($file, json_encode($default, JSON_PRETTY_PRINT));
}
$balances = json_decode(file_get_contents($file), true);

// Updated conversion rates (USD per unit)
$rates = [
    "capsule_mb"   => 0.25,  // 25 cents per MB
    "cache_mb"     => 0.15,  // 15 cents per MB
    "real_kwh"     => 0.15,  // 15 cents per kWh
    "bandwidth"    => 0.30,  // 30 cents per unit (assuming GB or as-is)
    "torrent_mb"   => 0.15,  // 15 cents per MB (priced in USD, swappable via WD)
    "watts_dollar" => 0.0294 // ~0.0294 USD per WD (from 17 WD = 0.50 USD)
];

// Input from JS
$from   = $_POST['swapFrom'] ?? '';
$to     = $_POST['swapTo'] ?? '';
$amount = isset($_POST['swapAmount']) ? (float)$_POST['swapAmount'] : 0;
$is_usd_payment = isset($_POST['isUsdPayment']) && $_POST['isUsdPayment'] === 'true'; // Flag for real USD via Stripe
$stripe_payment_id = $_POST['stripePaymentId'] ?? ''; // Optional: Verify Stripe charge ID

// Strict validation: No swap if invalid inputs or zero/negative amount
if (empty($from) || empty($to) || $amount <= 0 || !isset($balances[$from]) || !isset($balances[$to])) {
    echo json_encode(["status"=>"error","message"=>"Invalid swap request: From/To must be valid assets, amount > 0"]);
    exit;
}

// Validate rates
if (!isset($rates[$from]) || !isset($rates[$to])) {
    echo json_encode(["status"=>"error","message"=>"Unsupported asset type"]);
    exit;
}

// Pure balance-based check: Only allow if exact balance permits (no overdraw)
if (!isset($balances[$from]) || $balances[$from] < $amount) {
    echo json_encode(["status"=>"error","message"=>"Insufficient $from balance: You have {$balances[$from]}, need at least $amount"]);
    exit;
}

// Handle USD payment verification (min $0.01 for real USD swaps - only if flagged)
if ($is_usd_payment) {
    if ($amount < 0.01) {
        echo json_encode(["status"=>"error","message"=>"USD payments require at least $0.01"]);
        exit;
    }
    // Verify Stripe payment (integrate with stripe_handler.php - see below)
    // For now, assume verified if payment_id provided; in prod, call verifyStripeCharge()
    if (empty($stripe_payment_id)) {
        echo json_encode(["status"=>"error","message"=>"Stripe payment verification required for USD"]);
        exit;
    }
    // Deduct 1 penny fee for USD processing
    $fee = 0.01;
    if ($amount <= $fee) {
        echo json_encode(["status"=>"error","message"=>"Amount too low after fee"]);
        exit;
    }
    $net_amount = $amount - $fee;
    // Add to profit_usd
    $balances['profit_usd'] += $net_amount;
    // Bonus logic: For every 0.50 USD net, add 17 WD
    $bonus_wd = floor($net_amount / 0.50) * 17;
    if ($bonus_wd > 0) {
        $balances['watts_dollar'] += $bonus_wd;
    }
    // Special: If exact 0.21 USD sent, split net to kWh and WD (e.g., 50/50 value)
    if (round($amount, 2) == 0.21) {
        $split_usd = $net_amount / 2;
        $kwh_bonus = $split_usd / $rates['real_kwh'];
        $wd_bonus = $split_usd / $rates['watts_dollar'];
        $balances['real_kwh'] += $kwh_bonus;
        $balances['watts_dollar'] += $wd_bonus;
    }
    // Unlock feature if profit >=10
    if ($balances['profit_usd'] >= 10.0 && !$balances['feature_unlocked']) {
        $balances['feature_unlocked'] = true;
    }
}

// Internal swaps are free (no fee if not USD payment) - only if balance allows
$usdValue = $amount / $rates[$from];
$toValue  = $usdValue * $rates[$to];

// Update balances - only deduct/credit if all checks pass
$balances[$from] -= $amount;
$balances[$to]   += $toValue;
$balances['last_updated'] = gmdate("c");

// Save balances
file_put_contents($file, json_encode($balances, JSON_PRETTY_PRINT));

// Log entry
$entry = [
    'timestamp'   => date('Y-m-d H:i:s'),
    'from_asset'  => $from,
    'to_asset'    => $to,
    'amount_from' => $amount,
    'amount_to'   => $toValue,
    'is_usd_payment' => $is_usd_payment,
    'action'      => 'swap'
];
$logData = file_exists($log) ? json_decode(file_get_contents($log), true) : [];
$logData[] = $entry;
file_put_contents($log, json_encode($logData, JSON_PRETTY_PRINT));

// USD swap-out logic (if unlocked and swapping to USD)
if ($balances['feature_unlocked'] && $to === 'usd_value' && $usdValue >= 10.0) {
    $payout_usd = floor($usdValue / 10.0) * 8.0; // $8 per $10
    // In prod, trigger Stripe payout to user wallet (see usd_payout.php below)
    $entry['payout_usd'] = $payout_usd;
}

// Respond
$message = "Swapped ".round($amount,4)." $from into ".round($toValue,4)." $to successfully! (Based on your exact $from balance of {$balances[$from] + $amount})";
if ($is_usd_payment) {
    $message .= " (USD fee: $0.01, Profit added: $$net_amount)";
    if ($bonus_wd > 0) $message .= ", Bonus WD: $bonus_wd";
    if ($balances['feature_unlocked']) $message .= " (USD payout feature unlocked!)";
}
echo json_encode([
    "status"   => "ok",
    "message"  => $message,
    "balances" => $balances
]);
?>