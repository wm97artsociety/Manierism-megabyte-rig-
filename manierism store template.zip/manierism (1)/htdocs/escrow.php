<?php
// escrow.php — LIST ALL ACTIVE ESCROW ORDERS + STRIPE CONNECT INTEGRATION
// Fetches active listings + verifies payment status using Stripe API

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=UTF-8');

require_once 'vendor/autoload.php'; // Stripe PHP library

// YOUR STRIPE SECRET KEY (REPLACE WITH YOUR NEW KEY AFTER REVOKING THE OLD ONE)
\Stripe\Stripe::setApiKey(''); // PLACEHOLDER - USE NEW KEY

$escrow_dir = __DIR__ . '/escrow';
$listings = [];

if (is_dir($escrow_dir)) {
    foreach (glob($escrow_dir . '/*.json') as $file) {
        $data = json_decode(file_get_contents($file), true);
        if ($data && ($data['status'] ?? '') === 'active') {
            // STRIPE CONNECT: Verify if payment is pending/completed for this listing
            $payment_status = 'pending';
            if (isset($data['payment_intent_id'])) {
                try {
                    $payment_intent = \Stripe\PaymentIntent::retrieve($data['payment_intent_id']);
                    $payment_status = $payment_intent->status; // 'succeeded', 'requires_action', etc.
                    
                    // If succeeded, update listing status
                    if ($payment_status === 'succeeded') {
                        $data['status'] = 'completed';
                        file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));
                    }
                } catch (Exception $e) {
                    $payment_status = 'error: ' . $e->getMessage();
                }
            }
            
            $data['payment_status'] = $payment_status;
            $listings[] = $data;
        }
    }
}

echo json_encode([
    'status' => 'ok',
    'listings' => $listings,
    'total' => count($listings)
], JSON_PRETTY_PRINT);
?>