<?php
// ledger.php — logs every purchase/listing
date_default_timezone_set('UTC');
$log_file = __DIR__ . '/ledger.log';

$entry = [
  'timestamp' => date('Y-m-d H:i:s'),
  'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
  'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
  'product' => $_GET['product'] ?? 'unknown',
  'amount' => $_GET['amount'] ?? '0',
  'kwh' => $_GET['kwh'] ?? '0',
  'price' => $_GET['price'] ?? '0',
  'wallet' => $_GET['wallet'] ?? 'unknown'
];

file_put_contents($log_file, json_encode($entry) . PHP_EOL, FILE_APPEND | LOCK_EX);

echo json_encode(["status" => "logged"]);
?>