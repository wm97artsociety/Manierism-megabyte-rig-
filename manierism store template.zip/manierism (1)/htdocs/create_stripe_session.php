<?php
// Load config for Stripe keys and URLs (from earlier setup)
include 'config.php'; // Assumes STRIPE_SECRET_KEY, SUCCESS_URL_BASE, CANCEL_URL_BASE defined there
require_once('vendor/autoload.php'); // Stripe PHP library via Composer

\Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);

header('Content-Type: application/json');

$product = $_POST['product'] ?? null; // e.g., 'kwh_bundle' or 'wd_bonus'
$amount_usd_cents = (int)($_POST['amount_usd_cents'] ?? 0); // e.g., 50 for $0.50
$order_id = $_POST['order_id'] ?? null;
$buyer_id = $_POST['buyer_id'] ?? null; // User ID for crediting balances

// Validation
if (!$product || $amount_usd_cents < 1 || !$order_id || !$buyer_id) { // Min 1 cent
    echo json_encode(['status' => 'error', 'message' => 'Missing required payment details or amount too low (min 1¢).']);
    exit;
}

$amount_usd = $amount_usd_cents / 100.0; // Convert to dollars

// Dynamic credits based on updated rates (from swap.php)
// Rates: WD ~$0.0294 each (17 WD / $0.50), kWh $0.15 each
// Deduct 1¢ fee for USD processing, then bonus: 17 WD per $0.50 net
$fee_cents = 1; // 1 penny fee
if ($amount_usd_cents <= $fee_cents) {
    echo json_encode(['status' => 'error', 'message' => 'Amount too low after 1¢ fee.']);
    exit;
}
$net_usd = ($amount_usd_cents - $fee_cents) / 100.0;

$kilowatts_to_credit = 0.0; // Default 0; only for special cases
$watts_dollar_to_credit = floor($net_usd / 0.50) * 17.0; // 17 WD per $0.50 net

// Special: If total paid == 21¢, split net to kWh and WD (50/50 value)
if ($amount_usd_cents == 21) {
    $split_usd = $net_usd / 2.0;
    $kilowatts_to_credit = $split_usd / 0.15; // At $0.15/kWh
    $watts_dollar_to_credit = $split_usd / 0.0294; // At ~$0.0294/WD
}

// Product-specific (e.g., for 'kwh_bundle', credit more kWh)
if ($product === 'kwh_bundle') {
    $kilowatts_to_credit += $net_usd / 0.15; // Full net to kWh at rate
    $watts_dollar_to_credit += floor($net_usd / 0.50) * 17.0; // Plus WD bonus
}

// Also add to profit_usd for unlock
$balances_file = __DIR__ . '/balances.json';
$balances = json_decode(file_exists($balances_file) ? file_get_contents($balances_file) : json_encode([]), true);
$balances['profit_usd'] = ($balances['profit_usd'] ?? 0.0) + $net_usd;
if ($balances['profit_usd'] >= 10.0 && !($balances['feature_unlocked'] ?? false)) {
    $balances['feature_unlocked'] = true;
}
file_put_contents($balances_file, json_encode($balances, JSON_PRETTY_PRINT)); // Temp credit; confirm on webhook

// Dynamic product name/description
$product_name = match($product) {
    'kwh_bundle' => number_format($kilowatts_to_credit, 0) . ' Kilowatts Bundle',
    'wd_bonus' => number_format($watts_dollar_to_credit, 2) . ' Watts Dollars Bonus',
    default => 'Resource Bundle'
};
$description = "Net after 1¢ fee: $" . number_format($net_usd, 2) . ". Credits: " . number_format($kilowatts_to_credit, 0) . " kWh, $" . number_format($watts_dollar_to_credit, 2) . " WD.";

try {
    $checkout_session = \Stripe\Checkout\Session::create([
        'payment_method_types' => ['card'],
        'line_items' => [[
            'price_data' => [
                'currency' => 'usd',
                'product_data' => [
                    'name' => $product_name,
                    'description' => $description,
                ],
                'unit_amount' => $amount_usd_cents, // Total including fee
            ],
            'quantity' => 1,
        ]],
        'mode' => 'payment',
        'success_url' => (SUCCESS_URL_BASE ?? 'https://your-site.com/success') . '?session_id={CHECKOUT_SESSION_ID}&order_id=' . urlencode($order_id),
        'cancel_url' => (CANCEL_URL_BASE ?? 'https://your-site.com/cancel') . '?order_id=' . urlencode($order_id),
        'metadata' => [
            'order_id' => $order_id,
            'buyer_id' => $buyer_id,
            'product' => $product,
            'net_usd' => $net_usd,
            'kwh_amount' => $kilowatts_to_credit,
            'watts_dollar_amount' => $watts_dollar_to_credit,
            'fee_cents' => $fee_cents,
        ],
    ]);

    echo json_encode([
        'status' => 'success',
        'checkout_url' => $checkout_session->url,
        'session_id' => $checkout_session->id,
    ]);

} catch (\Exception $e) {
    // Rollback temp profit if error
    $balances['profit_usd'] -= $net_usd;
    file_put_contents($balances_file, json_encode($balances, JSON_PRETTY_PRINT));
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Stripe API Error: ' . $e->getMessage(),
    ]);
}
?>