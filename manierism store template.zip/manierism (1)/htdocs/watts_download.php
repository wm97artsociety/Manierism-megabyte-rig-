<?php
$file = __DIR__ . "/william_usd_value_100000000000000000000000000000000000000000000000000000000000000000_json.json";

header('Content-Type: application/json');
header('Content-Disposition: attachment; filename="watts_usd.json"');
readfile($file);
exit;
?>
