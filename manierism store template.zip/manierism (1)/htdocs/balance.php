<?php
header('Content-Type: application/json; charset=UTF-8');

// --- Database credentials ---
$servername = "sql300.infinityfree.com";
$username   = "if0_40369406";
$password   = "cUin0bBKIPktwX0";
$dbname     = "if0_40369406_manierism";

// --- Connect with mysqli and check errors ---
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Connection failed"]);
    exit();
}

// --- Prepare and execute query ---
$sql = "SELECT token, balance FROM balances";
$result = $conn->query($sql);

$balances = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        // sanitize output
        $balances[] = [
            "token"   => htmlspecialchars($row['token']),
            "balance" => (float)$row['balance']
        ];
    }
    $result->free();
} else {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Query failed"]);
    $conn->close();
    exit();
}

// --- Respond with JSON ---
echo json_encode([
    "status"   => "ok",
    "balances" => $balances
]);

$conn->close();
?>
