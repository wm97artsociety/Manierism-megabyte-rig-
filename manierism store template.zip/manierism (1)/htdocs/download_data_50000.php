<?php
header('Content-Type: application/json');
header('Content-Disposition: attachment; filename="data_50000_mbps.json"');

$data = [
    "wallet_id" => "manierism",
    "rig_id"    => "data_mega",
    "node_id"   => uniqid("data-50k-"),
    "resource"  => "bandwidth_MBps",
    "amount"    => 50000.0,
    "timestamp" => microtime(true),
    "overlay_constants" => [
        "TEЛ²" => "8.88e+17",
        "E²Л" => "2.54e+34",
        "block_header" => "MMBLOCKHEADER2025"
    ],
    "capsule_settlement" => [
        "plant_name" => "Manierism Data Center",
        "currency"   => "MBps",
        "value"      => "50,000 MB/s perpetual",
        "note"       => "50,000 MB/s — unlimited — infinite bandwidth"
    ]
];

echo json_encode($data, JSON_PRETTY_PRINT);
?>