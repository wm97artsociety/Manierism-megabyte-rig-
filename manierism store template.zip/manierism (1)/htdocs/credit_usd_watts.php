<?php
// credit_usd_watts.php — Adds $0.80 USD and 0.35 Watts Dollar to balances.json
declare(strict_types=1);

header('Content-Type: application/json');

$file     = __DIR__ . '/balances.json';
$log_file = __DIR__ . '/trades_log.json';

// Credit amounts
$USD_CREDIT   = 0.80;
$WATTS_CREDIT = 0.35;

// --- 1. Lock and read balances ---
$fp = fopen($file, 'c+');
if (!$fp || !flock($fp, LOCK_EX)) {
    http_response_code(500);
    exit(json_encode(["status"=>"error","message"=>"Balance file error/lock failed"]));
}

$balances = json_decode(stream_get_contents($fp), true) ?? [];

// Ensure defaults if missing
if (!is_array($balances)) $balances = [];
$balances['usd_value']    = $balances['usd_value']    ?? 0.0;
$balances['watts_dollar'] = $balances['watts_dollar'] ?? 0.0;

// --- 2. Apply credits ---
$balances['usd_value']    += $USD_CREDIT;
$balances['watts_dollar'] += $WATTS_CREDIT;
$balances['last_updated']  = gmdate("c");

// --- 3. Write back balances ---
ftruncate($fp, 0); rewind($fp);
fwrite($fp, json_encode($balances, JSON_PRETTY_PRINT));
fflush($fp); flock($fp, LOCK_UN); fclose($fp);

// --- 4. Log trade ---
$log_entry = [
    'timestamp'    => date('Y-m-d H:i:s'),
    'wallet_id'    => 'trust',
    'action'       => 'credit_usd_watts',
    'usd_credit'   => $USD_CREDIT,
    'watts_credit' => $WATTS_CREDIT
];

$fpLog = fopen($log_file, 'c+');
if ($fpLog && flock($fpLog, LOCK_EX)) {
    $data = stream_get_contents($fpLog, -1, 0);
    $current_log = !empty($data) ? json_decode($data, true) : [];
    if (!is_array($current_log)) $current_log = [];
    $current_log[] = $log_entry;
    ftruncate($fpLog, 0); rewind($fpLog);
    fwrite($fpLog, json_encode($current_log, JSON_PRETTY_PRINT));
    flock($fpLog, LOCK_UN);
    fclose($fpLog);
}

// --- 5. Respond ---
echo json_encode([
    "status"   => "ok",
    "message"  => "Credited $USD_CREDIT USD and $WATTS_CREDIT Watts Dollar",
    "balances" => $balances
], JSON_PRETTY_PRINT);
exit;
?>
