<?php
header('Content-Type: application/json');

$counterFile = 'downloads_5M.json';

if (file_exists($counterFile)) {
    $downloads = json_decode(file_get_contents($counterFile), true);
    $count = count($downloads);
} else {
    $count = 0;
}

echo json_encode(['download_count_5M' => $count]);
