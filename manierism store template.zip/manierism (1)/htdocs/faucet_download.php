<?php
date_default_timezone_set('UTC');

// --- Config ---
$AMOUNT_PER_DOWNLOAD_WATTS_DOLLAR = 1.0;
$FAUCET_COUNT_FILE = __DIR__ . '/watts_faucet_count.txt';
$LOG_DIR = __DIR__ . '/faucet_logs';
$HOURLY_LIMIT_SECONDS = 3600;

// --- IP Rate Limit ---
$ip = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
$ip_log_file = $LOG_DIR . '/' . md5($ip) . '.log';

if (!is_dir($LOG_DIR)) {
    mkdir($LOG_DIR, 0775, true);
}

if (file_exists($ip_log_file) && (time() - filemtime($ip_log_file)) < $HOURLY_LIMIT_SECONDS) {
    http_response_code(429);
    die("⛔ IP restricted. Please wait 1 hour for the next free download.");
}

file_put_contents($ip_log_file, gmdate("c"));

// --- Update Faucet Count ---
$currentCount = file_exists($FAUCET_COUNT_FILE) ? (int)file_get_contents($FAUCET_COUNT_FILE) : 0;
file_put_contents($FAUCET_COUNT_FILE, $currentCount + 1);

// --- Generate Capsule JSON ---
$receiptId = bin2hex(random_bytes(8));
$timestampUnix = microtime(true);

$capsule = [
    "wallet_id" => "trust",
    "rig_id" => "trust",
    "node_id" => "c590fb1b-44c5-4bd9-b6d1-e2ce14fd1df3",
    "resource" => "watts_dollar",
    "amount" => $AMOUNT_PER_DOWNLOAD_WATTS_DOLLAR,
    "timestamp" => $timestampUnix,
    "overlay_constants" => [
        "TEЛ² constant" => "8.88 x 10¹⁷",
        "E²Л constant" => "2.54 x 10³⁴"
    ],
    "receipt_meta" => [
        "receipt_id" => $receiptId,
        "issued_at" => gmdate("c"),
        "source" => "Watts Dollar Faucet - Artifact"
    ]
];

// --- Send Download ---
header('Content-Type: application/json');
header('Content-Disposition: attachment; filename="faucet_1wattdollar_' . $receiptId . '.json"');
echo json_encode($capsule, JSON_PRETTY_PRINT);
exit;
?>
