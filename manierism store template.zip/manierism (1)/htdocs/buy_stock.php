<?php
// buy_stock.php — log trades, save order, and redirect to dynamic Stripe Checkout

ob_start(); 

// 1. --- STRIPE SDK SETUP ---
require __DIR__ . '/vendor/autoload.php'; 

// Use your Stripe Secret Key (sk_live_xxx)
\Stripe\Stripe::setApiKey(''); 

require __DIR__ . '/db.php';
session_start();

// Configuration
$USD_PER_TRADE = 0.50;  // Fixed price per trade unit
$KWH_PER_TRADE = 150;   // Fixed Kilowatt Hours per trade unit
$log_file      = __DIR__ . "/trades_log.json";

// Replace with your actual success and cancel URLs
$SUCCESS_URL = 'https://manierismegabyte.infinityfreeapp.com/success.php'; 
$CANCEL_URL  = 'https://manierismegabyte.infinityfreeapp.com/stock.html';

$walletId = $_SESSION['wallet_id'] ?? 'trust';
$trades   = max(1, intval($_POST['count'] ?? 1)); 

// --- Calculation ---
$totalUsd   = $trades * $USD_PER_TRADE; 
$totalKwh   = $trades * $KWH_PER_TRADE; 

// Stripe expects the amount in cents (integer)
$unitAmountCents = (int) round($USD_PER_TRADE * 100);

// --- Save order in DB ---
$stmt = $pdo->prepare("INSERT INTO orders (wallet_id, trades, usd_amount, created_at) 
                       VALUES (:wid, :trades, :usd, NOW())");
$stmt->execute([
    ':wid'    => $walletId,
    ':trades' => $trades,
    ':usd'    => $totalUsd
]);

// --- Log trade ---
$watts_dollar = round($totalUsd * 34.0, 4); 
$log_entry = [
    'timestamp'    => date('Y-m-d H:i:s'),
    'wallet_id'    => $walletId,
    'trade_type'   => 'usd',
    'trade_count'  => $trades,
    'usd_amount'   => round($totalUsd, 4),
    'watts_dollar' => $watts_dollar,
    'kwh_amount'   => $totalKwh, 
    'action'       => 'stock_bought_awaiting_stripe_payment'
];

$current_log = file_exists($log_file) ? json_decode(file_get_contents($log_file), true) : [];
if (!is_array($current_log)) $current_log = [];
$current_log[] = $log_entry;
file_put_contents($log_file, json_encode($current_log, JSON_PRETTY_PRINT));

// --- 2. CREATE STRIPE CHECKOUT SESSION ---
try {
    $session = \Stripe\Checkout\Session::create([
        'payment_method_types' => ['card'],
        'line_items' => [[
            'price_data' => [
                'currency' => 'usd',
                'product_data' => [
                    'name' => "Kilowatt Trades ({$KWH_PER_TRADE} kWh per trade)",
                ],
                'unit_amount' => $unitAmountCents,
            ],
            'quantity' => $trades,
        ]],
        'mode' => 'payment',
        'success_url' => $SUCCESS_URL . '?session_id={CHECKOUT_SESSION_ID}',
        'cancel_url' => $CANCEL_URL,
    ]);

    // --- 3. REDIRECT TO STRIPE CHECKOUT ---
    header("Location: " . $session->url);
    ob_end_flush();
    exit;

} catch (\Exception $e) {
    error_log("Stripe Checkout Error: " . $e->getMessage());
    echo "<h1>Error creating checkout session.</h1><p>Please check your Stripe API keys and network connection.</p>";
    http_response_code(500);
    ob_end_flush();
    exit;
}
?>
