<?php
date_default_timezone_set('UTC');

// --- Config for 150 kWh capsule ---
$AMOUNT_PER_DOWNLOAD_KWH = 150.0;
$BALANCE_FILE   = __DIR__ . '/balance.json';   // master balance file
$LEDGER_FILE    = __DIR__ . '/ledger/kwh_events.log';
$RECEIPTS_DIR   = __DIR__ . '/kwh_receipts';
$PAID_COUNT_FILE= __DIR__ . '/kwh_paid_count.txt';

// --- Ensure directories exist ---
if (!is_dir($RECEIPTS_DIR)) mkdir($RECEIPTS_DIR, 0775, true);
if (!is_dir(dirname($LEDGER_FILE))) mkdir(dirname($LEDGER_FILE), 0775, true);

// --- 1. Lock, Read, and Validate Balance ---
$fp = fopen($BALANCE_FILE, 'c+');
if (!$fp || !flock($fp, LOCK_EX)) {
    http_response_code(500);
    exit("Balance file error/lock failed");
}

$balance = json_decode(stream_get_contents($fp), true) ?? [];
$remaining_amount = $balance['remaining_kwh'] ?? 0;

if ($remaining_amount < $AMOUNT_PER_DOWNLOAD_KWH) {
    flock($fp, LOCK_UN); fclose($fp);
    http_response_code(409);
    exit("Insufficient balance for 150 kWh. Remaining: " . $remaining_amount);
}

// --- 2. Deduct and Update Balance ---
$balance['remaining_kwh'] -= $AMOUNT_PER_DOWNLOAD_KWH;
$balance['last_updated'] = gmdate("c");

ftruncate($fp, 0); rewind($fp);
fwrite($fp, json_encode($balance, JSON_PRETTY_PRINT));
fflush($fp); flock($fp, LOCK_UN); fclose($fp);

// --- 3. Update Paid Count ---
$currentCount = file_exists($PAID_COUNT_FILE) ? (int)file_get_contents($PAID_COUNT_FILE) : 0;
file_put_contents($PAID_COUNT_FILE, $currentCount + 1);

// --- 4. Generate Receipt ---
$receiptId = bin2hex(random_bytes(8));
$capsule = [
  "wallet_id" => $balance['wallet_id'] ?? "trust",
  "rig_id"    => $balance['rig_id'] ?? "trust",
  "node_id"   => $balance['node_id'] ?? uniqid("energy-"),
  "resource"  => "real_kwh",
  "amount"    => $AMOUNT_PER_DOWNLOAD_KWH,
  "timestamp" => microtime(true),
  "overlay_constants" => $balance['overlay_constants'] ?? [
      "TEЛ²"        => "8.88e+17",
      "E²Л"         => "2.54e+34",
      "block_header"=> "MM_BLOCK_HEADER_2025"
  ],
  "capsule_settlement" => $balance['capsule_settlement'] ?? [
      "plant_name"   => "Manierism Electrism",
      "currency"     => "USD",
      "usd_value"    => 0.50,
      "rate_per_kwh" => round(0.50/150, 8)
  ],
  "receipt_meta" => [
    "receipt_id" => $receiptId,
    "issued_at"  => gmdate("c"),
    "source"     => "150 kWh Purchase"
  ]
];
file_put_contents($RECEIPTS_DIR . "/receipt_kwh_" . $receiptId . ".json", json_encode($capsule, JSON_PRETTY_PRINT));

// --- 5. Log Ledger ---
$ledgerEntry = [
  "type" => "kwh_download_150",
  "amount" => $AMOUNT_PER_DOWNLOAD_KWH,
  "remaining_balance" => $balance['remaining_kwh'],
  "receipt_id" => $receiptId,
  "ip" => $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN',
  "at" => gmdate("c")
];
file_put_contents($LEDGER_FILE, json_encode($ledgerEntry) . "\n", FILE_APPEND | LOCK_EX);

// --- 6. Send Download ---
header('Content-Type: application/json');
header('Content-Disposition: attachment; filename="receipt_kwh_150_' . $receiptId . '.json"');
echo json_encode($capsule, JSON_PRETTY_PRINT);
exit;
?>
