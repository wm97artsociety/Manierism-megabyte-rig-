<?php
// check_pending.php - Check status of pending payments (client poll)
header('Content-Type: application/json; charset=utf-8');

$pending_file = __DIR__ . '/pending_payments.json';
$wallets_dir = __DIR__ . '/wallets';

$input = json_decode(file_get_contents('php://input'), true) ?: $_GET;
$wallet_id = $input['wallet_id'] ?? null;
$pending_id = $input['pending_id'] ?? null;

if (!$wallet_id) {
    echo json_encode(['status' => 'error', 'message' => 'Missing wallet_id']);
    exit;
}

$pendings = file_exists($pending_file) ? json_decode(file_get_contents($pending_file), true) : [];

$user_pendings = array_filter($pendings, fn($p) => $p['wallet_id'] === $wallet_id && $p['status'] === 'pending');
$pending_count = count($user_pendings);

if ($pending_id) {
    $specific = array_filter($pendings, fn($p) => $p['pending_id'] === $pending_id);
    if (empty($specific)) {
        echo json_encode(['status' => 'not_found', 'message' => 'Pending not found']);
        exit;
    }
    $pending = reset($specific);
    echo json_encode([
        'status' => $pending['status'],
        'message' => $pending['status'] === 'confirmed' ? 'Payment confirmed and balance updated' : 'Still pending'
    ]);
} else {
    echo json_encode([
        'status' => 'ok',
        'pending_count' => $pending_count,
        'message' => $pending_count > 0 ? "You have {$pending_count} pending payments" : 'No pending payments'
    ]);
}
?>