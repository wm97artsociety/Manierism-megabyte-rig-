<?php
// schema_orderbook.php — create tables for order book + trades
declare(strict_types=1);
require __DIR__ . '/db.php';

try {
    // Order book table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS order_book (
            id         INT AUTO_INCREMENT PRIMARY KEY,
            type       ENUM('bid','ask') NOT NULL,
            price      DECIMAL(18,8) NOT NULL,
            quantity   DECIMAL(18,8) NOT NULL,
            wallet_id  VARCHAR(64),
            timestamp  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ");

    // Trades table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS trades (
            trade_id   INT AUTO_INCREMENT PRIMARY KEY,
            bid_id     INT,
            ask_id     INT,
            price      DECIMAL(18,8) NOT NULL,
            quantity   DECIMAL(18,8) NOT NULL,
            wallet_id  VARCHAR(64),
            type       ENUM('buy','sell','swap') NOT NULL,
            timestamp  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (bid_id) REFERENCES order_book(id) ON DELETE SET NULL,
            FOREIGN KEY (ask_id) REFERENCES order_book(id) ON DELETE SET NULL
        )
    ");

    echo "✅ Order book + trades schema created successfully.";
} catch (PDOException $e) {
    http_response_code(500);
    echo "❌ Database error: " . $e->getMessage();
} catch (Throwable $e) {
    http_response_code(500);
    echo "❌ Unexpected error: " . $e->getMessage();
}
