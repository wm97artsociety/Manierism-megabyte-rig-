<?php
// search_tokens.php — token search
require __DIR__ . '/db.php';

header("Access-Control-Allow-Origin: *");
header("Content-Type: text/html; charset=UTF-8");

$query = trim($_GET['query'] ?? '');

if ($query === '') {
    echo "<p>Please enter a token symbol or name.</p>";
    exit;
}

$stmt = $pdo->prepare("
    SELECT symbol, name, price_usd 
    FROM tokens 
    WHERE symbol LIKE ? OR name LIKE ? 
    ORDER BY symbol ASC 
    LIMIT 50
");
$like = '%' . $query . '%';
$stmt->execute([$like, $like]);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($results) {
    foreach ($results as $row) {
        $symbol = htmlspecialchars($row['symbol']);
        $name   = htmlspecialchars($row['name']);
        $price  = htmlspecialchars($row['price_usd']);
        echo "<p><strong>{$symbol}</strong> — {$name} (Price: {$price} USD)</p>";
    }
} else {
    echo "<p>No tokens found for query: <em>" . htmlspecialchars($query) . "</em></p>";
}
