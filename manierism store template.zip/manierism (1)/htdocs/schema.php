<?php
// schema.php — create tables for stockmarket backend
declare(strict_types=1);
require __DIR__ . '/db.php';

try {
    // Balances table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS balances (
            wallet_id      VARCHAR(64) PRIMARY KEY,
            capsule_mb     DECIMAL(18,8) DEFAULT 0,
            cache_mb       DECIMAL(18,8) DEFAULT 0,
            real_kwh       DECIMAL(18,8) DEFAULT 0,
            bandwidth      DECIMAL(18,8) DEFAULT 0,
            torrent_mb     DECIMAL(18,8) DEFAULT 0,
            watts_dollar   DECIMAL(18,8) DEFAULT 0,
            usd_value      DECIMAL(18,8) DEFAULT 0,
            profit_usd     DECIMAL(18,8) DEFAULT 0,
            liquidity_usd  DECIMAL(18,8) DEFAULT 0,
            updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )
    ");

    // Tokens table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS tokens (
            symbol     VARCHAR(16) PRIMARY KEY,
            name       VARCHAR(128),
            price_usd  DECIMAL(18,8)
        )
    ");

    // Orders table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS orders (
            id          INT AUTO_INCREMENT PRIMARY KEY,
            wallet_id   VARCHAR(64),
            trades      INT,
            usd_amount  DECIMAL(18,8),
            created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ");

    // Order book table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS order_book (
            id         INT AUTO_INCREMENT PRIMARY KEY,
            type       ENUM('bid','ask') NOT NULL,
            price      DECIMAL(18,8) NOT NULL,
            quantity   DECIMAL(18,8) NOT NULL,
            wallet_id  VARCHAR(64),
            timestamp  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ");

    // Trades table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS trades (
            trade_id   INT AUTO_INCREMENT PRIMARY KEY,
            type       ENUM('buy','sell','swap') NOT NULL,
            price      DECIMAL(18,8),
            quantity   DECIMAL(18,8),
            wallet_id  VARCHAR(64),
            timestamp  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ");

    echo "✅ Schema created successfully.";
} catch (Exception $e) {
    http_response_code(500);
    echo "❌ Error creating schema: " . $e->getMessage();
}
