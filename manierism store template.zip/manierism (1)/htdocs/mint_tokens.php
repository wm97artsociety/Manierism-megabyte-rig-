<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=UTF-8');

$file = __DIR__ . '/balances.json';
if (!file_exists($file)) {
    echo json_encode(["status"=>"error","message"=>"Balances file missing"]);
    exit;
}
$balances = json_decode(file_get_contents($file), true);

$symbol = $_POST['tokenSymbol'] ?? '';
$supply = (float)($_POST['initialSupply'] ?? 0);
$value  = (float)($_POST['baseValue'] ?? 0);

if (!$symbol || $supply <= 0 || $value <= 0) {
    echo json_encode(["status"=>"error","message"=>"Invalid mint parameters"]);
    exit;
}

// Add new token balance
$balances[$symbol] = $supply;
$balances["watts_dollar"] += $value;

file_put_contents($file, json_encode($balances, JSON_PRETTY_PRINT));

echo json_encode(["status"=>"ok","message"=>"Token $symbol minted","balances"=>$balances]);
