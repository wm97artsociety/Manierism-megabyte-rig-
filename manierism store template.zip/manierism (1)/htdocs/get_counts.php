<?php
header('Content-Type: application/json');

// --- Configuration ---
$FAUCET_COUNT_FILE       = 'faucet_count.txt';
$PAID_COUNT_FILE         = 'paid_count.txt';
$BINARY5M_COUNT_FILE     = 'binary5M_count.txt'; // Updated for 5 million kWh
$WATTS5M_COUNT_FILE      = 'watts5M_count.txt';  // Optional, if you track Watts
// --- End Configuration ---

function read_count($file_path) {
    if (!file_exists($file_path)) {
        return 0;
    }
    return (int)trim(file_get_contents($file_path));
}

// Read all counts
$faucet_count       = read_count($FAUCET_COUNT_FILE);
$paid_count         = read_count($PAID_COUNT_FILE);
$binary5M_count     = read_count($BINARY5M_COUNT_FILE);
$watts5M_count      = read_count($WATTS5M_COUNT_FILE);

// Output JSON with all counters
echo json_encode([
    'faucet_count'       => $faucet_count,
    'paid_count'         => $paid_count,
    'binary5M_count'     => $binary5M_count,
    'watts5M_count'      => $watts5M_count
]);
?>
