<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$balances_file = __DIR__ . '/balances.json';

// --- Default balances ---
$default_balances = [
    "capsule_mb"     => 125.00,
    "cache_mb"       => 250.00,
    "real_kwh"       => 150.000000,
    "bandwidth"      => 100.00,
    "torrent_mb"     => 50.00,
    "watts_dollar"   => 7.50,
    "usd_value"      => 0.00,
    "kilowatt_liquidity_usd"  => 100000.00
];

// --- Try database first ---
$servername = "";
$username   = "";
$password   = "";
$dbname     = "";

$balances = [];

$conn = @new mysqli($servername, $username, $password, $dbname);
if ($conn && !$conn->connect_error) {
    $sql = "SELECT token, balance FROM balances";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $balances[$row['token']] = is_numeric($row['balance']) ? (float)$row['balance'] : 0.0;
        }
    }
    $conn->close();
}

// --- If DB failed or empty, use local JSON ---
if (empty($balances)) {
    if (file_exists($balances_file)) {
        $decoded = json_decode(file_get_contents($balances_file), true);
        if (is_array($decoded)) $balances = $decoded;
    }
    if (empty($balances)) {
        $balances = $default_balances;
        file_put_contents($balances_file, json_encode($balances, JSON_PRETTY_PRINT));
    }
}

// --- Normalize floats ---
foreach ($balances as $k => $v) {
    $balances[$k] = is_numeric($v) ? (float)$v : 0.0;
}

// --- Respond ---
echo json_encode([
    "status"   => "ok",
    "balances" => $balances
], JSON_PRETTY_PRINT);
exit;
