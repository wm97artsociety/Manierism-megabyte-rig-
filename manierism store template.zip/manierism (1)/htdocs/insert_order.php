<?php
// insert_order.php — add a bid or ask
declare(strict_types=1);
require __DIR__ . '/db.php';

header('Content-Type: application/json; charset=UTF-8');

// --- Helper for errors ---
function sendError(string $message, int $status_code = 400): void {
    http_response_code($status_code);
    echo json_encode(["status" => "error", "message" => $message]);
    exit();
}

// --- Validate inputs ---
$type     = strtolower(trim($_POST['type'] ?? 'bid'));
$price    = isset($_POST['price']) ? (float)$_POST['price'] : 0.0;
$quantity = isset($_POST['quantity']) ? (float)$_POST['quantity'] : 0.0;

if (!in_array($type, ['bid','ask'], true)) {
    sendError("Invalid order type. Must be 'bid' or 'ask'.");
}
if ($price <= 0 || $quantity <= 0) {
    sendError("Price and quantity must be positive numbers.");
}

try {
    // Insert order
    $stmt = $pdo->prepare("INSERT INTO order_book (type, price, quantity) VALUES (:type,:price,:quantity)");
    $stmt->execute([
        ':type'     => $type,
        ':price'    => $price,
        ':quantity' => $quantity
    ]);

    // Run matching engine after insert
    require __DIR__ . '/match_engine.php';
    if (function_exists('matchOrders')) {
        matchOrders($pdo);
    }

    echo json_encode([
        "status"   => "ok",
        "message"  => "Order inserted",
        "type"     => $type,
        "price"    => $price,
        "quantity" => $quantity
    ]);
} catch (PDOException $e) {
    sendError("Database error: " . $e->getMessage(), 500);
} catch (Throwable $e) {
    sendError("Unexpected error: " . $e->getMessage(), 500);
}
