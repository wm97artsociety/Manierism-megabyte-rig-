<?php
// match_engine.php — match highest bid vs lowest ask
function matchOrders(PDO $pdo) {
    // highest bid
    $bid = $pdo->query("SELECT * FROM order_book WHERE type='bid' AND quantity>0 ORDER BY price DESC LIMIT 1")->fetch();
    // lowest ask
    $ask = $pdo->query("SELECT * FROM order_book WHERE type='ask' AND quantity>0 ORDER BY price ASC LIMIT 1")->fetch();

    if ($bid && $ask && $bid['price'] >= $ask['price']) {
        $tradePrice = $ask['price'];
        $tradeQty   = min($bid['quantity'],$ask['quantity']);

        // record trade
        $stmt = $pdo->prepare("INSERT INTO trades (bid_id, ask_id, price, quantity) VALUES (?,?,?,?)");
        $stmt->execute([$bid['id'],$ask['id'],$tradePrice,$tradeQty]);

        // update remaining quantities
        $pdo->prepare("UPDATE order_book SET quantity=quantity-? WHERE id=?")->execute([$tradeQty,$bid['id']]);
        $pdo->prepare("UPDATE order_book SET quantity=quantity-? WHERE id=?")->execute([$tradeQty,$ask['id']]);
    }
}
?>
