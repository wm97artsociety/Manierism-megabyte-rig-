<?php
// purchase_binary.php
// After successful payment processing (Stripe or other gateway),
// redirect to the thank-you HTML page.

header("Location: thank.html?product=index&amount=500000");
exit;
?>
