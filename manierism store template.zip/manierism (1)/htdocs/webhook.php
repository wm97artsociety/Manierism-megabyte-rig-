<?php
// webhook_donation.php — FINAL VERSION THAT WORKS WITH YOUR CURRENT wallet_balances.php
header('Content-Type: application/json');
require_once 'vendor/autoload.php';

// === YOUR KEYS ===
\Stripe\Stripe::setApiKey('');
$webhookSecret = 'whsec_your_real_webhook_secret_here'; // ← CHANGE IN STRIPE DASHBOARD!

$payload = @file_get_contents('php://input');
$sigHeader = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';

try {
    $event = \Stripe\Webhook::constructEvent($payload, $sigHeader, $webhookSecret);
} catch (Exception $e) {
    http_response_code(400);
    error_log('Webhook error: ' . $e->getMessage());
    exit();
}

if ($event->type !== 'checkout.session.completed') {
    http_response_code(200);
    exit();
}

$session = $event->data->object;
if ($session->payment_status !== 'paid') {
    http_response_code(200);
    exit();
}

// === GET USER WALLET ID (YOU MUST SEND THIS FROM JS!) ===
$user_wallet_id = $session->metadata->user_wallet_id 
               ?? $session->client_reference_id 
               ?? null;

if (empty($user_wallet_id)) {
    error_log('DONATION ERROR: Missing wallet_id for session ' . $session->id);
    http_response_code(400);
    exit();
}

// === CALCULATE REWARD: $1 = 34 Watts Dollar → $50 = 1700 ===
$usd_amount = $session->amount_total / 100;
$watts_reward = $usd_amount * 34;

// === CREDIT VIA YOUR EXISTING wallet_balances.php ===
$credit_url = "https://your-site.com/wallet_balances.php"
            . "?action=donation_50"
            . "&wallet_id=" . urlencode($user_wallet_id);

file_get_contents($credit_url);

// === LOG DONATION ===
$log_file = __DIR__ . '/donation_log.json';
$log = file_exists($log_file) ? json_decode(file_get_contents($log_file), true) : [];
$log[] = [
    'timestamp'      => date('c'),
    'wallet_id'      => $user_wallet_id,
    'usd_donated'    => $usd_amount,
    'watts_credited' => $watts_reward,
    'payment_id'     => $session->payment_intent ?? $session->id,
    'email'          => $session->customer_details->email ?? 'anonymous'
];
file_put_contents($log_file, json_encode($log, JSON_PRETTY_PRINT));

echo json_encode([
    'status'         => 'success',
    'wallet_id'      => $user_wallet_id,
    'usd_received'   => $usd_amount,
    'watts_credited' => $watts_reward,
    'message'        => "Donation processed: +{$watts_reward} Watts Dollar"
]);

http_response_code(200);
?>