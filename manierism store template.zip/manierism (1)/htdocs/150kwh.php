<?php
// 150 kWh Faucet Script — download_kwh_150.php

session_start();

// File to track downloads (simple JSON file)
$counterFile = __DIR__ . '/downloads_150.json';

// Limit: 1 download per IP every 24 hours
$ip = $_SERVER['REMOTE_ADDR'];
$now = time();
$limit_seconds = 24 * 60 * 60; // 24 hours

// Load counter data
if (file_exists($counterFile)) {
    $downloads = json_decode(file_get_contents($counterFile), true);
} else {
    $downloads = [];
}

// Check if IP has already downloaded in the last 24 hours
if (isset($downloads[$ip]) && ($now - $downloads[$ip]['timestamp']) < $limit_seconds) {
    $remaining = $limit_seconds - ($now - $downloads[$ip]['timestamp']);
    $hours = floor($remaining / 3600);
    $minutes = floor(($remaining % 3600) / 60);
    die("⚡ You have already claimed your 150 kWh capsule in the last 24 hours. Please wait {$hours}h {$minutes}m.");
}

// Prepare 150 kWh JSON file
$fileData = [
    "resource" => "real_kwh",
    "chunk_size" => "150 kWh Capsule",
    "delivery" => "JSON file auto-generated",
    "data_core" => "manierism electrism",
    "wallet_id" => "trust",
    "rig_id" => "trust",
    "node_id" => uniqid('node_', true),
    "resource_type" => "kilowatt_hours",
    "amount_transferred" => "150 kWh",
    "timestamp" => microtime(true),
    "block_header" => "MMBLOCKHEADER2025",
    "constants" => [
        "TEL2" => "8.88 × 10¹⁷",
        "E2L"  => "2.54 × 10³⁴"
    ],
    "uses" => [
        "Symbolic energy capsule for trading",
        "Update wallet balances on dashboard",
        "Resell as a micro energy capsule"
    ],
    "amplification" => [
        ["mode" => "Linear", "multiplier" => "34.0", "output" => "5,100 kWh equivalent"],
        ["mode" => "Binary", "multiplier" => "2⁶⁵", "output" => "∞"]
    ]
];

// Send file to browser
$filename = "150_kWh_capsule_" . date("Ymd_His") . ".json";
header('Content-Type: application/json');
header('Content-Disposition: attachment; filename="' . $filename . '"');
echo json_encode($fileData, JSON_PRETTY_PRINT);

// Update download counter for this IP
$downloads[$ip] = ['timestamp' => $now];
file_put_contents($counterFile, json_encode($downloads, JSON_PRETTY_PRINT));

exit;
?>
