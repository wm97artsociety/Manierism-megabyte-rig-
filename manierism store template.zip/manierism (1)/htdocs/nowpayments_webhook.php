<?php
// nowpayments_webhook.php - Handles Instant Payment Notifications (IPN) from NOWPayments
// This script performs security checks, deducts capacity from the resource JSON,
// and credits the user's real_kwh balance upon payment confirmation.

// --- 0. Setup and Configuration ---
// Requires a separate db.php file for database connection ($pdo).
require __DIR__ . '/db.php'; 

// The secret key provided by the user and set in the NOWPayments IPN settings
$ipnSecret = ''; 
$balancesFile = __DIR__ . '/balances.json'; // Where the user's wallet balances are stored (read by wallet_balanaces.php)
$capsuleFile = __DIR__ . '/5M_kWh_capsule_20251123_000522.json'; // The JSON file to deduct kilowatts from
$logFile = __DIR__ . '/trades_log.json';

// Function for internal debugging and error logging
function log_message(string $level, string $message): void {
    // Note: In a live environment, use a robust logging solution. This is simple file logging.
    error_log(date('Y-m-d H:i:s') . " [$level] Webhook: $message\n", 3, __DIR__ . '/webhook_debug.log');
}

// --- 1. Security Check: Validate IPN Signature ---
// This prevents unauthorized parties from triggering fulfillment.
$signature = $_SERVER['HTTP_X_NOWPAYMENTS_SIG'] ?? '';
$payload = file_get_contents('php://input');

if (empty($signature) || hash_hmac('sha512', $payload, $ipnSecret) !== $signature) {
    log_message('ERROR', 'Invalid IPN signature received.');
    http_response_code(403); // Forbidden
    exit;
}

$data = json_decode($payload, true);
$status = $data['payment_status'] ?? 'unknown';
$orderId = $data['order_id'] ?? null;
// $paidAmount = $data['actually_paid'] ?? 0; // Not used for fulfillment, but useful for checks

log_message('INFO', "Processing IPN for Order ID: $orderId. Status: $status.");

// --- 2. Process only 'finished' payments ---
if ($status !== 'finished') {
    // Acknowledge receipt, but ignore payments in status like 'waiting', 'confirming', or 'expired'.
    http_response_code(200); 
    exit;
}

if (!$orderId) {
    log_message('ERROR', "Missing Order ID in IPN data.");
    http_response_code(400); 
    exit;
}

// --- 3. Fetch Order Details from Database ---
$stmt = $pdo->prepare("SELECT wallet_id, trades, status FROM orders WHERE order_id = :oid");
$stmt->execute([':oid' => $orderId]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    log_message('ERROR', "Order ID $orderId not found in local database.");
    http_response_code(404);
    exit;
}

$walletId = $order['wallet_id'];
// 'trades' is the amount of kWh the user paid for in buy_stock.php
$purchasedKwh = (int)$order['trades']; 

// Prevent double crediting
if ($order['status'] === 'fulfilled') {
    log_message('WARNING', "Order ID $orderId already fulfilled.");
    http_response_code(200);
    exit;
}

// --- 4. Resource Deduction from Global Capsule JSON (Atomic File Operation) ---
$capsule = [];
$fpCapsule = fopen($capsuleFile, 'c+'); // Open for read/write, create if needed

if ($fpCapsule && flock($fpCapsule, LOCK_EX)) {
    $dataCapsule = stream_get_contents($fpCapsule, -1, 0); 
    $capsule = json_decode($dataCapsule, true) ?? [];

    $remainingCapacity = $capsule['remaining_kwh_capacity'] ?? 5000000.0;
    
    if ($remainingCapacity < $purchasedKwh) {
        // Log resource failure and skip credit, but unlock the file
        log_message('ERROR', "Insufficient capacity. Remaining: $remainingCapacity. Purchased: $purchasedKwh.");
        flock($fpCapsule, LOCK_UN);
        fclose($fpCapsule);
        $pdo->prepare("UPDATE orders SET status = 'failed_resource' WHERE order_id = :oid")->execute([':oid' => $orderId]);
        http_response_code(500); // Server error: Resource issue
        exit;
    }

    // Deduct the linear amount (1:1 deduction)
    $capsule['remaining_kwh_capacity'] = $remainingCapacity - $purchasedKwh;
    $capsule['remaining_kwh_capacity'] = round($capsule['remaining_kwh_capacity'], 4);

    // Write the updated capsule back
    ftruncate($fpCapsule, 0);
    rewind($fpCapsule);
    fwrite($fpCapsule, json_encode($capsule, JSON_PRETTY_PRINT));
    flock($fpCapsule, LOCK_UN);
    fclose($fpCapsule);

} else {
    log_message('ERROR', "Could not lock/open capsule file: $capsuleFile");
    http_response_code(500);
    exit;
}

// --- 5. Credit Kilowatts to User's Balance JSON (Atomic File Operation) ---
$balances = [];
$fpBalances = fopen($balancesFile, 'c+');

if ($fpBalances && flock($fpBalances, LOCK_EX)) {
    $dataBalances = stream_get_contents($fpBalances, -1, 0); 
    $balances = json_decode($dataBalances, true) ?? ['real_kwh' => 0.0, 'capsule_mb' => 0.0, 'watts_dollar' => 0.0]; 

    // Ensure the required field exists and is numeric
    if (!isset($balances['real_kwh']) || !is_numeric($balances['real_kwh'])) {
         $balances['real_kwh'] = 0.0;
    }
    
    // Add the purchased kilowatts (1:1 credit)
    $balances['real_kwh'] += $purchasedKwh;
    $balances['real_kwh'] = round($balances['real_kwh'], 4); // Keep it clean

    // Update DB status to fulfilled BEFORE writing to file, for consistency
    $pdo->prepare("UPDATE orders SET status = 'fulfilled', fulfilled_at = NOW() WHERE order_id = :oid")
        ->execute([':oid' => $orderId]);

    // Log the successful fulfillment
    $log_entry = [
        'timestamp'      => date('Y-m-d H:i:s'),
        'wallet_id'      => $walletId,
        'action'         => 'payment_fulfilled',
        'order_id'       => $orderId,
        'kwh_credited'   => $purchasedKwh,
        'new_balance'    => $balances['real_kwh']
    ];
    $current_log = file_exists($logFile) ? json_decode(file_get_contents($logFile), true) : [];
    if (!is_array($current_log)) $current_log = [];
    $current_log[] = $log_entry;
    // Write log separately (this file does not need the same lock as the primary data files)
    file_put_contents($logFile, json_encode($current_log, JSON_PRETTY_PRINT), LOCK_EX);


    // Write the updated balance back
    ftruncate($fpBalances, 0);
    rewind($fpBalances);
    fwrite($fpBalances, json_encode($balances, JSON_PRETTY_PRINT));
    flock($fpBalances, LOCK_UN);
    fclose($fpBalances);

} else {
    log_message('ERROR', "Could not lock/open balance file: $balancesFile");
    http_response_code(500);
    exit;
}

// --- 6. Final Acknowledgement ---
// NOWPayments expects a 200 OK response to confirm the IPN was successfully processed.
http_response_code(200);
echo "IPN received and processed successfully.";
?>