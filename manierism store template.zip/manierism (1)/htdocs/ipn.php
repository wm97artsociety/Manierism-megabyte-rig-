<?php
// ipn.php — handle NOWPayments Instant Payment Notifications (IPN)
// This script should be set as your ipn_callback_url in buy/sell/cashout requests.

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$log_file = __DIR__ . "/trades_log.json";

// --- Read raw POST body ---
$raw = file_get_contents("php://input");
$data = json_decode($raw, true);

if (!$data || !isset($data['payment_status'])) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Invalid IPN payload"]);
    exit();
}

// --- Extract relevant fields ---
$payment_status = $data['payment_status']; // e.g. finished, waiting, expired
$order_id       = $data['order_id'] ?? '';
$payment_id     = $data['payment_id'] ?? '';
$pay_amount     = $data['pay_amount'] ?? 0;
$pay_currency   = $data['pay_currency'] ?? '';
$price_amount   = $data['price_amount'] ?? 0;
$price_currency = $data['price_currency'] ?? 'usd';

// --- Build log entry ---
$log_entry = [
    'timestamp'    => date('Y-m-d H:i:s'),
    'wallet_id'    => $data['wallet_id'] ?? 'trust',
    'trade_type'   => $price_currency,
    'trade_count'  => $price_amount,
    'usd_amount'   => round((float)$price_amount, 4),
    'watts_dollar' => round((float)$price_amount * 34.0, 4),
    'kwh_amount'   => 0,
    'action'       => "ipn_" . $payment_status,
    'order_id'     => $order_id,
    'payment_id'   => $payment_id,
    'pay_amount'   => $pay_amount,
    'pay_currency' => $pay_currency
];

// --- Append to trades_log.json ---
$current_log = file_exists($log_file) ? json_decode(file_get_contents($log_file), true) : [];
if (!is_array($current_log)) $current_log = [];
$current_log[] = $log_entry;
file_put_contents($log_file, json_encode($current_log, JSON_PRETTY_PRINT));

// --- Respond to NOWPayments ---
echo json_encode(["status" => "ok", "message" => "IPN processed", "payment_status" => $payment_status]);
exit();
?>
