<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=UTF-8');

$orders_file = __DIR__ . "/orders.json";

if (!file_exists($orders_file)) {
    echo json_encode([
        "status" => "ok",
        "orders" => [],
        "count" => 0
    ], JSON_PRETTY_PRINT);
    exit;
}

$raw = file_get_contents($orders_file);
$orders = json_decode($raw, true);

if (!is_array($orders)) {
    echo json_encode([
        "status" => "error",
        "message" => "orders.json is corrupted"
    ], JSON_PRETTY_PRINT);
    exit;
}

// Attach defaults and clean formatting
$cleaned = [];
foreach ($orders as $o) {
    $cleaned[] = [
        "id" => $o["id"] ?? uniqid(),
        "type" => strtoupper($o["type"] ?? "UNKNOWN"),
        "watts_dollar" => floatval($o["watts_dollar"] ?? 0),
        "usd_amount" => floatval($o["usd_amount"] ?? 0),
        "created_at" => $o["created_at"] ?? gmdate("c"),
        "status" => $o["status"] ?? "OPEN"
    ];
}

echo json_encode([
    "status" => "ok",
    "orders" => $cleaned,
    "count" => count($cleaned)
], JSON_PRETTY_PRINT);
?>